﻿namespace SUNCodeGenerator
{
    partial class ClassViwer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ClassViwer));
            this.RTB1 = new ICSharpCode.TextEditor.TextEditorControl();
            this.SuspendLayout();
            // 
            // RTB1
            // 
            this.RTB1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.RTB1.Encoding = ((System.Text.Encoding)(resources.GetObject("RTB1.Encoding")));
            this.RTB1.Location = new System.Drawing.Point(0, 0);
            this.RTB1.Name = "RTB1";
            this.RTB1.ShowEOLMarkers = true;
            this.RTB1.ShowInvalidLines = false;
            this.RTB1.ShowMatchingBracket = false;
            this.RTB1.ShowSpaces = true;
            this.RTB1.ShowTabs = true;
            this.RTB1.ShowVRuler = true;
            this.RTB1.Size = new System.Drawing.Size(563, 394);
            this.RTB1.TabIndex = 4;
            this.RTB1.Load += new System.EventHandler(this.RTB1_Load);
            this.RTB1.Changed += new System.EventHandler(this.RTB1_Changed);
            // 
            // ClassViwer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 394);
            this.Controls.Add(this.RTB1);
            this.Name = "ClassViwer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Class Viwer";
            this.ResumeLayout(false);

        }

        #endregion

        private ICSharpCode.TextEditor.TextEditorControl RTB1;
    }
}