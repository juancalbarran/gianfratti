﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SUNCodeGenerator
{
    public partial class frmNewConnection : Form
    {
        public frmNewConnection()
        {
            InitializeComponent();
        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void butTest_Click(object sender, EventArgs e)
        {
            txtDB.Items.Clear();
            SqlConnection conn = new SqlConnection("Server=" + txtServer.Text + ";DataBase=Master;UID=" + txtUID.Text + ";PWD=" + txtPWD.Text + ";");
            SqlCommand cmd = new SqlCommand("sp_databases", conn);
            SqlDataReader rdr;
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();

                while (rdr.Read())
                {
                    txtDB.Items.Add(rdr[0].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
                conn.Dispose();
                cmd.Dispose();
            }
        }

        private string m_DataBase;

        public string DataBase
        {
            get { return m_DataBase; }
            set { m_DataBase = value; }
        }

        private string m_Connectionstring;

        public string ConnectionString
        {
            get { return m_Connectionstring; }
            set { m_Connectionstring = value; }
        }


        private void butOk_Click(object sender, EventArgs e)
        {
            if (txtDB.Text != "")
            {
                DataBase = txtDB.Text;
                ConnectionString = "Server=" + txtServer.Text + ";DataBase=" + txtDB.Text + ";UID=" + txtUID.Text + ";PWD=" + txtPWD.Text + ";";
                this.Hide();
            }
        }
    }
}