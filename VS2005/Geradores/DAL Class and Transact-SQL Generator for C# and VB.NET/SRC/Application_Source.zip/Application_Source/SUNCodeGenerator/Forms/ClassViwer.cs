﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;

namespace SUNCodeGenerator
{
    public partial class ClassViwer : Form
    {

        public ClassViwer(string CodeType, string code, string Title, string tablename)
        {
            InitializeComponent();

            string path = Application.StartupPath + @"\XML";
            FileSyntaxModeProvider provider = new FileSyntaxModeProvider(path);
            HighlightingManager manager = HighlightingManager.Manager;
            manager.AddSyntaxModeFileProvider(provider);
            this.RTB1.Document.HighlightingStrategy = manager.FindHighlighter(CodeType);
            RTB1.Refresh();
            RTB1.Text = code;
            RTB1.ShowTabs = false;
            RTB1.ShowSpaces = false;
            RTB1.ShowEOLMarkers = false;
            this.Text = Title;
            Code = code;
            this.VCodeType = CodeType;
            this.TableName = tablename;
            if (CodeType == "CSharp")
                this.Passvand = "cs";
            else
                this.Passvand = "SQL";

        }

        private string m_passvand;

        public string Passvand
        {
            get { return m_passvand; }
            set { m_passvand = value; }
        }


        private string m_TableName;
        public string TableName
        {
            get { return m_TableName; }
            set { m_TableName = value; }
        }

        private string m_VCodeType;
        public string VCodeType
        {
            get { return m_VCodeType; }
            set { m_VCodeType = value; }
        }

        public ClassViwer()
        {
            InitializeComponent();
        }

        private string m_Code;

        public string Code
        {
            get { return m_Code; }
            set
            {
                m_Code = value;

            }
        }

        private void RTB1_Load(object sender, EventArgs e)
        {

        }

        private void RTB1_Changed(object sender, EventArgs e)
        {
            RTB1.Text = Code;
        }

    }
}