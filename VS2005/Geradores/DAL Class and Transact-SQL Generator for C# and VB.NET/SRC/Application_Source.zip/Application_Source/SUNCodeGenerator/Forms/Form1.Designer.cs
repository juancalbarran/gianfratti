namespace SUNCodeGenerator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Tables", 1, 1);
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("", 0, 0, new System.Windows.Forms.TreeNode[] {
            treeNode3});
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TV1 = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.PG1 = new System.Windows.Forms.PropertyGrid();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.classViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.storedProcedureViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteProcedureViewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateProcedureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.selectProcedureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sandBarManager1 = new TD.SandBar.SandBarManager();
            this.bottomSandBarDock = new TD.SandBar.ToolBarContainer();
            this.leftSandBarDock = new TD.SandBar.ToolBarContainer();
            this.rightSandBarDock = new TD.SandBar.ToolBarContainer();
            this.topSandBarDock = new TD.SandBar.ToolBarContainer();
            this.menuBar1 = new TD.SandBar.MenuBar();
            this.menuBarItem1 = new TD.SandBar.MenuBarItem();
            this.menuButtonItem1 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem2 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem3 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem18 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem4 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem5 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem6 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem7 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem8 = new TD.SandBar.MenuButtonItem();
            this.menuBarItem2 = new TD.SandBar.MenuBarItem();
            this.menuButtonItem9 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem10 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem11 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem12 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem13 = new TD.SandBar.MenuButtonItem();
            this.menuBarItem3 = new TD.SandBar.MenuBarItem();
            this.menuButtonItem17 = new TD.SandBar.MenuButtonItem();
            this.menuBarItem4 = new TD.SandBar.MenuBarItem();
            this.menuButtonItem14 = new TD.SandBar.MenuButtonItem();
            this.menuBarItem5 = new TD.SandBar.MenuBarItem();
            this.menuButtonItem15 = new TD.SandBar.MenuButtonItem();
            this.menuButtonItem16 = new TD.SandBar.MenuButtonItem();
            this.toolBar1 = new TD.SandBar.ToolBar();
            this.buttonItem1 = new TD.SandBar.ButtonItem();
            this.buttonItem2 = new TD.SandBar.ButtonItem();
            this.buttonItem3 = new TD.SandBar.ButtonItem();
            this.buttonItem4 = new TD.SandBar.ButtonItem();
            this.buttonItem5 = new TD.SandBar.ButtonItem();
            this.buttonItem6 = new TD.SandBar.ButtonItem();
            this.buttonItem7 = new TD.SandBar.ButtonItem();
            this.buttonItem8 = new TD.SandBar.ButtonItem();
            this.buttonItem9 = new TD.SandBar.ButtonItem();
            this.buttonItem13 = new TD.SandBar.ButtonItem();
            this.toolBar2 = new TD.SandBar.ToolBar();
            this.buttonItem10 = new TD.SandBar.ButtonItem();
            this.buttonItem11 = new TD.SandBar.ButtonItem();
            this.buttonItem12 = new TD.SandBar.ButtonItem();
            this.sandDockManager1 = new TD.SandDock.SandDockManager();
            this.leftSandDock = new TD.SandDock.DockContainer();
            this.dockControl2 = new TD.SandDock.DockControl();
            this.rightSandDock = new TD.SandDock.DockContainer();
            this.dockControl1 = new TD.SandDock.DockControl();
            this.bottomSandDock = new TD.SandDock.DockContainer();
            this.dockControl3 = new TD.SandDock.DockControl();
            this.txtResult = new System.Windows.Forms.RichTextBox();
            this.topSandDock = new TD.SandDock.DockContainer();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.contextMenuStrip1.SuspendLayout();
            this.topSandBarDock.SuspendLayout();
            this.leftSandDock.SuspendLayout();
            this.dockControl2.SuspendLayout();
            this.rightSandDock.SuspendLayout();
            this.dockControl1.SuspendLayout();
            this.bottomSandDock.SuspendLayout();
            this.dockControl3.SuspendLayout();
            this.SuspendLayout();
            // 
            // TV1
            // 
            this.TV1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TV1.ImageIndex = 0;
            this.TV1.ImageList = this.imageList1;
            this.TV1.Location = new System.Drawing.Point(0, 0);
            this.TV1.Name = "TV1";
            treeNode3.ImageIndex = 1;
            treeNode3.Name = "Node1";
            treeNode3.SelectedImageIndex = 1;
            treeNode3.Text = "Tables";
            treeNode4.ImageIndex = 0;
            treeNode4.Name = "Node0";
            treeNode4.SelectedImageIndex = 0;
            treeNode4.Text = "";
            this.TV1.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode4});
            this.TV1.SelectedImageIndex = 0;
            this.TV1.Size = new System.Drawing.Size(199, 215);
            this.TV1.TabIndex = 0;
            this.TV1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.TV1_AfterSelect);
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "DataBase.png");
            this.imageList1.Images.SetKeyName(1, "Folder.png");
            this.imageList1.Images.SetKeyName(2, "Table.png");
            this.imageList1.Images.SetKeyName(3, "Classes.png");
            this.imageList1.Images.SetKeyName(4, "Fields.png");
            this.imageList1.Images.SetKeyName(5, "Key.png");
            // 
            // PG1
            // 
            this.PG1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PG1.Location = new System.Drawing.Point(0, 0);
            this.PG1.Name = "PG1";
            this.PG1.Size = new System.Drawing.Size(190, 215);
            this.PG1.TabIndex = 2;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.classViewToolStripMenuItem,
            this.toolStripMenuItem1,
            this.storedProcedureViewToolStripMenuItem,
            this.deleteProcedureViewToolStripMenuItem,
            this.updateProcedureToolStripMenuItem,
            this.selectProcedureToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(198, 120);
            // 
            // classViewToolStripMenuItem
            // 
            this.classViewToolStripMenuItem.Name = "classViewToolStripMenuItem";
            this.classViewToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.classViewToolStripMenuItem.Text = "Class View";
            this.classViewToolStripMenuItem.Click += new System.EventHandler(this.classViewToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(194, 6);
            // 
            // storedProcedureViewToolStripMenuItem
            // 
            this.storedProcedureViewToolStripMenuItem.Name = "storedProcedureViewToolStripMenuItem";
            this.storedProcedureViewToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.storedProcedureViewToolStripMenuItem.Text = "Insert Procedure View";
            this.storedProcedureViewToolStripMenuItem.Click += new System.EventHandler(this.storedProcedureViewToolStripMenuItem_Click);
            // 
            // deleteProcedureViewToolStripMenuItem
            // 
            this.deleteProcedureViewToolStripMenuItem.Name = "deleteProcedureViewToolStripMenuItem";
            this.deleteProcedureViewToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.deleteProcedureViewToolStripMenuItem.Text = "Delete Procedure View";
            this.deleteProcedureViewToolStripMenuItem.Click += new System.EventHandler(this.deleteProcedureViewToolStripMenuItem_Click);
            // 
            // updateProcedureToolStripMenuItem
            // 
            this.updateProcedureToolStripMenuItem.Name = "updateProcedureToolStripMenuItem";
            this.updateProcedureToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.updateProcedureToolStripMenuItem.Text = "Update Procedure View";
            this.updateProcedureToolStripMenuItem.Click += new System.EventHandler(this.updateProcedureToolStripMenuItem_Click);
            // 
            // selectProcedureToolStripMenuItem
            // 
            this.selectProcedureToolStripMenuItem.Name = "selectProcedureToolStripMenuItem";
            this.selectProcedureToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.selectProcedureToolStripMenuItem.Text = "Select Procedure";
            this.selectProcedureToolStripMenuItem.Click += new System.EventHandler(this.selectProcedureToolStripMenuItem_Click);
            // 
            // sandBarManager1
            // 
            this.sandBarManager1.BottomContainer = this.bottomSandBarDock;
            this.sandBarManager1.LeftContainer = this.leftSandBarDock;
            this.sandBarManager1.OwnerForm = this;
            this.sandBarManager1.RightContainer = this.rightSandBarDock;
            this.sandBarManager1.TopContainer = this.topSandBarDock;
            // 
            // bottomSandBarDock
            // 
            this.bottomSandBarDock.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomSandBarDock.Location = new System.Drawing.Point(0, 426);
            this.bottomSandBarDock.Manager = this.sandBarManager1;
            this.bottomSandBarDock.Name = "bottomSandBarDock";
            this.bottomSandBarDock.Size = new System.Drawing.Size(664, 0);
            this.bottomSandBarDock.TabIndex = 7;
            // 
            // leftSandBarDock
            // 
            this.leftSandBarDock.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftSandBarDock.Location = new System.Drawing.Point(0, 76);
            this.leftSandBarDock.Manager = this.sandBarManager1;
            this.leftSandBarDock.Name = "leftSandBarDock";
            this.leftSandBarDock.Size = new System.Drawing.Size(0, 350);
            this.leftSandBarDock.TabIndex = 5;
            // 
            // rightSandBarDock
            // 
            this.rightSandBarDock.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightSandBarDock.Location = new System.Drawing.Point(664, 76);
            this.rightSandBarDock.Manager = this.sandBarManager1;
            this.rightSandBarDock.Name = "rightSandBarDock";
            this.rightSandBarDock.Size = new System.Drawing.Size(0, 350);
            this.rightSandBarDock.TabIndex = 6;
            // 
            // topSandBarDock
            // 
            this.topSandBarDock.Controls.Add(this.menuBar1);
            this.topSandBarDock.Controls.Add(this.toolBar1);
            this.topSandBarDock.Controls.Add(this.toolBar2);
            this.topSandBarDock.Dock = System.Windows.Forms.DockStyle.Top;
            this.topSandBarDock.Location = new System.Drawing.Point(0, 0);
            this.topSandBarDock.Manager = this.sandBarManager1;
            this.topSandBarDock.Name = "topSandBarDock";
            this.topSandBarDock.Size = new System.Drawing.Size(664, 76);
            this.topSandBarDock.TabIndex = 8;
            // 
            // menuBar1
            // 
            this.menuBar1.Buttons.AddRange(new TD.SandBar.ToolbarItemBase[] {
            this.menuBarItem1,
            this.menuBarItem2,
            this.menuBarItem3,
            this.menuBarItem4,
            this.menuBarItem5});
            this.menuBar1.Guid = new System.Guid("ed2d4c1d-22fa-476d-943e-9770c5ccd457");
            this.menuBar1.Location = new System.Drawing.Point(2, 0);
            this.menuBar1.Name = "menuBar1";
            this.menuBar1.Size = new System.Drawing.Size(662, 24);
            this.menuBar1.TabIndex = 0;
            // 
            // menuBarItem1
            // 
            this.menuBarItem1.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
            this.menuButtonItem1,
            this.menuButtonItem2,
            this.menuButtonItem3,
            this.menuButtonItem18,
            this.menuButtonItem4,
            this.menuButtonItem5,
            this.menuButtonItem6,
            this.menuButtonItem7,
            this.menuButtonItem8});
            this.menuBarItem1.Text = "&File";
            // 
            // menuButtonItem1
            // 
            this.menuButtonItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem1.Icon")));
            this.menuButtonItem1.Text = "&New";
            // 
            // menuButtonItem2
            // 
            this.menuButtonItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem2.Icon")));
            this.menuButtonItem2.Text = "&Open";
            // 
            // menuButtonItem3
            // 
            this.menuButtonItem3.BeginGroup = true;
            this.menuButtonItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem3.Icon")));
            this.menuButtonItem3.Text = "&Save As";
            // 
            // menuButtonItem18
            // 
            this.menuButtonItem18.Text = "Save";
            this.menuButtonItem18.Activate += new System.EventHandler(this.menuButtonItem18_Activate);
            // 
            // menuButtonItem4
            // 
            this.menuButtonItem4.BeginGroup = true;
            this.menuButtonItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem4.Icon")));
            this.menuButtonItem4.Text = "&Print";
            // 
            // menuButtonItem5
            // 
            this.menuButtonItem5.Text = "&Print Setup";
            // 
            // menuButtonItem6
            // 
            this.menuButtonItem6.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem6.Icon")));
            this.menuButtonItem6.Text = "&Print PreView";
            // 
            // menuButtonItem7
            // 
            this.menuButtonItem7.BeginGroup = true;
            this.menuButtonItem7.Text = "Properties";
            // 
            // menuButtonItem8
            // 
            this.menuButtonItem8.BeginGroup = true;
            this.menuButtonItem8.Text = "&Exit";
            // 
            // menuBarItem2
            // 
            this.menuBarItem2.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
            this.menuButtonItem9,
            this.menuButtonItem10,
            this.menuButtonItem11,
            this.menuButtonItem12,
            this.menuButtonItem13});
            this.menuBarItem2.Text = "&Edit";
            // 
            // menuButtonItem9
            // 
            this.menuButtonItem9.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem9.Icon")));
            this.menuButtonItem9.Text = "&Cut";
            // 
            // menuButtonItem10
            // 
            this.menuButtonItem10.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem10.Icon")));
            this.menuButtonItem10.Text = "&Copy";
            // 
            // menuButtonItem11
            // 
            this.menuButtonItem11.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem11.Icon")));
            this.menuButtonItem11.Text = "&Paste";
            // 
            // menuButtonItem12
            // 
            this.menuButtonItem12.BeginGroup = true;
            this.menuButtonItem12.Text = "&Select All";
            // 
            // menuButtonItem13
            // 
            this.menuButtonItem13.BeginGroup = true;
            this.menuButtonItem13.Text = "&Find and Replace";
            // 
            // menuBarItem3
            // 
            this.menuBarItem3.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
            this.menuButtonItem17});
            this.menuBarItem3.Text = "&Connection";
            // 
            // menuButtonItem17
            // 
            this.menuButtonItem17.Text = "New Connection";
            this.menuButtonItem17.Activate += new System.EventHandler(this.buttonItem10_Activate);
            // 
            // menuBarItem4
            // 
            this.menuBarItem4.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
            this.menuButtonItem14});
            this.menuBarItem4.Text = "&Window";
            // 
            // menuButtonItem14
            // 
            this.menuButtonItem14.Text = "Close All Documents";
            // 
            // menuBarItem5
            // 
            this.menuBarItem5.MenuItems.AddRange(new TD.SandBar.MenuButtonItem[] {
            this.menuButtonItem15,
            this.menuButtonItem16});
            this.menuBarItem5.Text = "&Help";
            // 
            // menuButtonItem15
            // 
            this.menuButtonItem15.Icon = ((System.Drawing.Icon)(resources.GetObject("menuButtonItem15.Icon")));
            this.menuButtonItem15.Text = "&Help";
            // 
            // menuButtonItem16
            // 
            this.menuButtonItem16.BeginGroup = true;
            this.menuButtonItem16.Text = "About Us";
            // 
            // toolBar1
            // 
            this.toolBar1.Buttons.AddRange(new TD.SandBar.ToolbarItemBase[] {
            this.buttonItem1,
            this.buttonItem2,
            this.buttonItem3,
            this.buttonItem4,
            this.buttonItem5,
            this.buttonItem6,
            this.buttonItem7,
            this.buttonItem8,
            this.buttonItem9,
            this.buttonItem13});
            this.toolBar1.DockLine = 1;
            this.toolBar1.Guid = new System.Guid("a9720fea-4f90-4170-91fb-6383d222b99d");
            this.toolBar1.Location = new System.Drawing.Point(2, 24);
            this.toolBar1.Name = "toolBar1";
            this.toolBar1.Size = new System.Drawing.Size(276, 26);
            this.toolBar1.TabIndex = 1;
            this.toolBar1.Text = "Main Toolbar";
            // 
            // buttonItem1
            // 
            this.buttonItem1.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem1.Icon")));
            this.buttonItem1.ToolTipText = "New";
            // 
            // buttonItem2
            // 
            this.buttonItem2.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem2.Icon")));
            this.buttonItem2.ToolTipText = "Open";
            // 
            // buttonItem3
            // 
            this.buttonItem3.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem3.Icon")));
            this.buttonItem3.ToolTipText = "Save";
            this.buttonItem3.Activate += new System.EventHandler(this.buttonItem3_Activate);
            // 
            // buttonItem4
            // 
            this.buttonItem4.BeginGroup = true;
            this.buttonItem4.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem4.Icon")));
            this.buttonItem4.ToolTipText = "Print";
            // 
            // buttonItem5
            // 
            this.buttonItem5.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem5.Icon")));
            this.buttonItem5.ToolTipText = "Print preview";
            // 
            // buttonItem6
            // 
            this.buttonItem6.BeginGroup = true;
            this.buttonItem6.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem6.Icon")));
            this.buttonItem6.ToolTipText = "Cut";
            // 
            // buttonItem7
            // 
            this.buttonItem7.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem7.Icon")));
            this.buttonItem7.ToolTipText = "Copy";
            // 
            // buttonItem8
            // 
            this.buttonItem8.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem8.Icon")));
            // 
            // buttonItem9
            // 
            this.buttonItem9.BeginGroup = true;
            this.buttonItem9.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem9.Icon")));
            this.buttonItem9.ToolTipText = "Help";
            // 
            // buttonItem13
            // 
            this.buttonItem13.Activate += new System.EventHandler(this.buttonItem13_Activate);
            // 
            // toolBar2
            // 
            this.toolBar2.Buttons.AddRange(new TD.SandBar.ToolbarItemBase[] {
            this.buttonItem10,
            this.buttonItem11,
            this.buttonItem12});
            this.toolBar2.DockLine = 2;
            this.toolBar2.Guid = new System.Guid("8dcaf508-3e34-4a21-917e-a8c3aa32405e");
            this.toolBar2.Location = new System.Drawing.Point(2, 50);
            this.toolBar2.Name = "toolBar2";
            this.toolBar2.Size = new System.Drawing.Size(94, 26);
            this.toolBar2.TabIndex = 2;
            this.toolBar2.Text = "Connection Toolbar";
            // 
            // buttonItem10
            // 
            this.buttonItem10.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem10.Icon")));
            this.buttonItem10.ToolTipText = "New Connection";
            this.buttonItem10.Activate += new System.EventHandler(this.buttonItem10_Activate);
            // 
            // buttonItem11
            // 
            this.buttonItem11.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem11.Icon")));
            this.buttonItem11.ToolTipText = "Execute Query";
            this.buttonItem11.Activate += new System.EventHandler(this.buttonItem11_Activate);
            // 
            // buttonItem12
            // 
            this.buttonItem12.Icon = ((System.Drawing.Icon)(resources.GetObject("buttonItem12.Icon")));
            this.buttonItem12.ToolTipText = "parse";
            // 
            // sandDockManager1
            // 
            this.sandDockManager1.OwnerForm = this;
            // 
            // leftSandDock
            // 
            this.leftSandDock.Controls.Add(this.dockControl2);
            this.leftSandDock.Dock = System.Windows.Forms.DockStyle.Left;
            this.leftSandDock.Guid = new System.Guid("b496dd47-7b2f-4569-a803-fdfc5964a26b");
            this.leftSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400, System.Windows.Forms.Orientation.Horizontal, new TD.SandDock.LayoutSystemBase[] {
            ((TD.SandDock.LayoutSystemBase)(new TD.SandDock.ControlLayoutSystem(199, 256, new TD.SandDock.DockControl[] {
                        this.dockControl2}, this.dockControl2)))});
            this.leftSandDock.Location = new System.Drawing.Point(0, 76);
            this.leftSandDock.Manager = this.sandDockManager1;
            this.leftSandDock.Name = "leftSandDock";
            this.leftSandDock.Size = new System.Drawing.Size(203, 256);
            this.leftSandDock.TabIndex = 9;
            // 
            // dockControl2
            // 
            this.dockControl2.Controls.Add(this.TV1);
            this.dockControl2.Guid = new System.Guid("aefcfb11-311a-4c15-9f40-b4dbc4d30171");
            this.dockControl2.Location = new System.Drawing.Point(0, 18);
            this.dockControl2.Name = "dockControl2";
            this.dockControl2.Size = new System.Drawing.Size(199, 215);
            this.dockControl2.TabIndex = 1;
            this.dockControl2.Text = "DataBase";
            // 
            // rightSandDock
            // 
            this.rightSandDock.Controls.Add(this.dockControl1);
            this.rightSandDock.Dock = System.Windows.Forms.DockStyle.Right;
            this.rightSandDock.Guid = new System.Guid("f7c855d0-cd7e-4554-abf7-68be751509eb");
            this.rightSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400, System.Windows.Forms.Orientation.Horizontal, new TD.SandDock.LayoutSystemBase[] {
            ((TD.SandDock.LayoutSystemBase)(new TD.SandDock.ControlLayoutSystem(190, 256, new TD.SandDock.DockControl[] {
                        this.dockControl1}, this.dockControl1)))});
            this.rightSandDock.Location = new System.Drawing.Point(470, 76);
            this.rightSandDock.Manager = this.sandDockManager1;
            this.rightSandDock.Name = "rightSandDock";
            this.rightSandDock.Size = new System.Drawing.Size(194, 256);
            this.rightSandDock.TabIndex = 10;
            // 
            // dockControl1
            // 
            this.dockControl1.Controls.Add(this.PG1);
            this.dockControl1.Guid = new System.Guid("9736b1ea-69ba-46e5-a930-b0af4bc22d21");
            this.dockControl1.Location = new System.Drawing.Point(4, 18);
            this.dockControl1.Name = "dockControl1";
            this.dockControl1.Size = new System.Drawing.Size(190, 215);
            this.dockControl1.TabIndex = 0;
            this.dockControl1.Text = "Property";
            // 
            // bottomSandDock
            // 
            this.bottomSandDock.Controls.Add(this.dockControl3);
            this.bottomSandDock.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomSandDock.Guid = new System.Guid("f6c62ddf-6913-4fa5-8902-ae9691b825f9");
            this.bottomSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400, System.Windows.Forms.Orientation.Horizontal, new TD.SandDock.LayoutSystemBase[] {
            ((TD.SandDock.LayoutSystemBase)(new TD.SandDock.ControlLayoutSystem(664, 90, new TD.SandDock.DockControl[] {
                        this.dockControl3}, this.dockControl3)))});
            this.bottomSandDock.Location = new System.Drawing.Point(0, 332);
            this.bottomSandDock.Manager = this.sandDockManager1;
            this.bottomSandDock.Name = "bottomSandDock";
            this.bottomSandDock.Size = new System.Drawing.Size(664, 94);
            this.bottomSandDock.TabIndex = 11;
            // 
            // dockControl3
            // 
            this.dockControl3.Controls.Add(this.txtResult);
            this.dockControl3.Guid = new System.Guid("7be040a4-0dfd-4382-b4b5-9dba1e547351");
            this.dockControl3.Location = new System.Drawing.Point(0, 22);
            this.dockControl3.Name = "dockControl3";
            this.dockControl3.Size = new System.Drawing.Size(664, 49);
            this.dockControl3.TabIndex = 1;
            this.dockControl3.Text = "Result";
            // 
            // txtResult
            // 
            this.txtResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtResult.Font = new System.Drawing.Font("Tahoma", 6.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.txtResult.Location = new System.Drawing.Point(0, 0);
            this.txtResult.Name = "txtResult";
            this.txtResult.Size = new System.Drawing.Size(664, 49);
            this.txtResult.TabIndex = 0;
            this.txtResult.Text = "Successfully (0 Error- 0 Warning)";
            // 
            // topSandDock
            // 
            this.topSandDock.Dock = System.Windows.Forms.DockStyle.Top;
            this.topSandDock.Guid = new System.Guid("d0f7ff9b-3356-417d-a69b-4bc4ee0a4be1");
            this.topSandDock.LayoutSystem = new TD.SandDock.SplitLayoutSystem(250, 400);
            this.topSandDock.Location = new System.Drawing.Point(0, 76);
            this.topSandDock.Manager = this.sandDockManager1;
            this.topSandDock.Name = "topSandDock";
            this.topSandDock.Size = new System.Drawing.Size(664, 0);
            this.topSandDock.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(664, 426);
            this.Controls.Add(this.leftSandDock);
            this.Controls.Add(this.rightSandDock);
            this.Controls.Add(this.bottomSandDock);
            this.Controls.Add(this.topSandDock);
            this.Controls.Add(this.leftSandBarDock);
            this.Controls.Add(this.rightSandBarDock);
            this.Controls.Add(this.bottomSandBarDock);
            this.Controls.Add(this.topSandBarDock);
            this.IsMdiContainer = true;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SUN Code Genarator";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.topSandBarDock.ResumeLayout(false);
            this.leftSandDock.ResumeLayout(false);
            this.dockControl2.ResumeLayout(false);
            this.rightSandDock.ResumeLayout(false);
            this.dockControl1.ResumeLayout(false);
            this.bottomSandDock.ResumeLayout(false);
            this.dockControl3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView TV1;
        private System.Windows.Forms.PropertyGrid PG1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem classViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storedProcedureViewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteProcedureViewToolStripMenuItem;
        private TD.SandBar.SandBarManager sandBarManager1;
        private TD.SandBar.ToolBarContainer bottomSandBarDock;
        private TD.SandBar.ToolBarContainer leftSandBarDock;
        private TD.SandDock.DockContainer leftSandDock;
        private TD.SandDock.SandDockManager sandDockManager1;
        private TD.SandDock.DockContainer rightSandDock;
        private TD.SandDock.DockControl dockControl1;
        private TD.SandDock.DockControl dockControl2;
        private TD.SandDock.DockContainer bottomSandDock;
        private TD.SandDock.DockContainer topSandDock;
        private TD.SandBar.ToolBarContainer rightSandBarDock;
        private TD.SandBar.ToolBarContainer topSandBarDock;
        private TD.SandBar.MenuBar menuBar1;
        private TD.SandBar.MenuBarItem menuBarItem1;
        private TD.SandBar.MenuBarItem menuBarItem2;
        private TD.SandBar.MenuBarItem menuBarItem3;
        private TD.SandBar.MenuBarItem menuBarItem4;
        private TD.SandBar.MenuBarItem menuBarItem5;
        private TD.SandBar.ToolBar toolBar1;
        private TD.SandBar.MenuButtonItem menuButtonItem1;
        private TD.SandBar.MenuButtonItem menuButtonItem2;
        private TD.SandBar.ButtonItem buttonItem1;
        private TD.SandBar.MenuButtonItem menuButtonItem3;
        private TD.SandBar.MenuButtonItem menuButtonItem4;
        private TD.SandBar.MenuButtonItem menuButtonItem5;
        private TD.SandBar.MenuButtonItem menuButtonItem6;
        private TD.SandBar.MenuButtonItem menuButtonItem7;
        private TD.SandBar.MenuButtonItem menuButtonItem8;
        private TD.SandBar.MenuButtonItem menuButtonItem9;
        private TD.SandBar.MenuButtonItem menuButtonItem10;
        private TD.SandBar.MenuButtonItem menuButtonItem11;
        private TD.SandBar.MenuButtonItem menuButtonItem12;
        private TD.SandBar.MenuButtonItem menuButtonItem13;
        private TD.SandBar.MenuButtonItem menuButtonItem14;
        private TD.SandBar.MenuButtonItem menuButtonItem15;
        private TD.SandBar.MenuButtonItem menuButtonItem16;
        private TD.SandBar.MenuButtonItem menuButtonItem17;
        private TD.SandBar.ButtonItem buttonItem2;
        private TD.SandBar.ButtonItem buttonItem3;
        private TD.SandBar.ButtonItem buttonItem4;
        private TD.SandBar.ButtonItem buttonItem5;
        private TD.SandBar.ButtonItem buttonItem6;
        private TD.SandBar.ButtonItem buttonItem7;
        private TD.SandBar.ButtonItem buttonItem8;
        private TD.SandBar.ButtonItem buttonItem9;
        private TD.SandBar.ToolBar toolBar2;
        private TD.SandBar.ButtonItem buttonItem10;
        private TD.SandBar.ButtonItem buttonItem11;
        private TD.SandBar.ButtonItem buttonItem12;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem updateProcedureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem selectProcedureToolStripMenuItem;
        private TD.SandDock.DockControl dockControl3;
        private System.Windows.Forms.RichTextBox txtResult;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private TD.SandBar.ButtonItem buttonItem13;
        private TD.SandBar.MenuButtonItem menuButtonItem18;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

