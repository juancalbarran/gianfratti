using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using ICSharpCode.TextEditor.Document;
using SUNCodeGenerator;

namespace SUNCodeGenerator
{
    public partial class Form1 : Form
    {

        public static string lConnectionString = "";
        public static string lDataBase = "";

        public Form1()
        {
            InitializeComponent();
        }

        public Form1(string ConnStr, string DB)
        {
            InitializeComponent();

            lConnectionString = ConnStr;
            lDataBase = DB;

        }

        private int FindID(string Name)
        {

            for (int i = 0; i < TV1.Nodes[0].Nodes[0].Nodes.Count; i++)
            {
                if (TV1.Nodes[0].Nodes[0].Nodes[i].Text == Name)
                {
                    return i;
                }
            }

            return -1;
        }

        private void CreateTree()
        {
            TV1.Nodes[0].Nodes[0].Nodes.Clear();
            //            TV1.Nodes[1].Nodes.Clear();

            SUNCodeGenerator.Classes.DataBaseInformation DI = new SUNCodeGenerator.Classes.DataBaseInformation(lConnectionString);
            for (int i = 0; i < DI.LoadTable().Count; i++)
            {
                TV1.Nodes[0].Nodes[0].Nodes.Add(DI.LoadTable()[i].ToString());
                TV1.Nodes[0].Nodes[0].Nodes[i].ImageIndex = 2;
                TV1.Nodes[0].Nodes[0].Nodes[i].SelectedImageIndex = 2;
                TV1.Nodes[0].Nodes[0].Nodes[i].ContextMenuStrip = contextMenuStrip1;
            }

            for (int j = 0; j < TV1.Nodes[0].Nodes[0].Nodes.Count; j++)
            {
                for (int k = 0; k < DI.LoadFileds(TV1.Nodes[0].Nodes[0].Nodes[j].Text).Count; k++)
                {
                    TV1.Nodes[0].Nodes[0].Nodes[FindID(TV1.Nodes[0].Nodes[0].Nodes[j].Text)].Nodes.Add(DI.LoadFileds(TV1.Nodes[0].Nodes[0].Nodes[j].Text)[k].ToString());
                    TV1.Nodes[0].Nodes[0].Nodes[FindID(TV1.Nodes[0].Nodes[0].Nodes[j].Text)].Nodes[k].ImageIndex = 4;
                    TV1.Nodes[0].Nodes[0].Nodes[FindID(TV1.Nodes[0].Nodes[0].Nodes[j].Text)].Nodes[k].SelectedImageIndex = 4;
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            TV1.Nodes[0].Text = lDataBase;
            CreateTree();
        }

        private void TV1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            try
            {

                //Load Property
                SUNCodeGenerator.Classes.FiledProperty FP = new SUNCodeGenerator.Classes.FiledProperty(lConnectionString, lDataBase, e.Node.Parent.Text, e.Node.Text);
                PG1.SelectedObject = FP;
                PG1.Enabled = false;

            }
            catch
            { }
        }

        private void classViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string tName = "";
            for (int i = 0; i < TV1.SelectedNode.Text.Length; i++)
            {
                if (TV1.SelectedNode.Text.Substring(i, 1) == " ")
                    tName += "_";
                else
                    tName += TV1.SelectedNode.Text.Substring(i, 1);
            }

            SUNCodeGenerator.Classes.GeneratorClass g = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, tName);
            SUNCodeGenerator.ClassViwer c = new ClassViwer("CSharp", g.ReturnClass(), tName + " - C#", tName);
            c.MdiParent = this;
            c.Show();

        }

        private void storedProcedureViewToolStripMenuItem_Click(object sender, EventArgs e)
        {

            string tName = "";
            for (int i = 0; i < TV1.SelectedNode.Text.Length; i++)
            {
                if (TV1.SelectedNode.Text.Substring(i, 1) == " ")
                    tName += "_";
                else
                    tName += TV1.SelectedNode.Text.Substring(i, 1);
            }

            SUNCodeGenerator.Classes.GeneratorClass g = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, tName);
            SUNCodeGenerator.ClassViwer c = new ClassViwer("TSQL", g.ReturnSQLInsert(), tName + " - (SQL-Insert)", tName);
            c.MdiParent = this;
            c.Show();
        }

        private void deleteProcedureViewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string tName = "";
            for (int i = 0; i < TV1.SelectedNode.Text.Length; i++)
            {
                if (TV1.SelectedNode.Text.Substring(i, 1) == " ")
                    tName += "_";
                else
                    tName += TV1.SelectedNode.Text.Substring(i, 1);
            }

            SUNCodeGenerator.Classes.GeneratorClass g = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, tName);
            SUNCodeGenerator.ClassViwer c = new ClassViwer("TSQL", g.ReturnSQLDelete(), tName + " - (SQL-Delete)", tName);
            c.MdiParent = this;
            c.Show();
        }

        private void buttonItem10_Activate(object sender, EventArgs e)
        {
            frmNewConnection log = new frmNewConnection();
            log.ShowDialog();
            lDataBase = log.DataBase;
            if (log.ConnectionString != null && log.DataBase != null)
            {
                lConnectionString = log.ConnectionString;
                TV1.Nodes[0].Text = lDataBase;
                CreateTree();
            }
            log.Dispose();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void buttonItem3_Activate(object sender, EventArgs e)
        {

            if (folderBrowserDialog1.ShowDialog() == DialogResult.Cancel)
            {
                return;
            }

            for (int i = 0; i < TV1.Nodes[0].Nodes[0].Nodes.Count; i++)
            {
                Classes.File f = new SUNCodeGenerator.Classes.File();
                Classes.GeneratorClass c = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, TV1.Nodes[0].Nodes[0].Nodes[i].Text);
                f.Save(TV1.Nodes[0].Nodes[0].Nodes[i].Text, folderBrowserDialog1.SelectedPath, c.ReturnClass(), "cs");
            }

        }

        private void updateProcedureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string tName = "";
            for (int i = 0; i < TV1.SelectedNode.Text.Length; i++)
            {
                if (TV1.SelectedNode.Text.Substring(i, 1) == " ")
                    tName += "_";
                else
                    tName += TV1.SelectedNode.Text.Substring(i, 1);
            }

            SUNCodeGenerator.Classes.GeneratorClass g = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, tName);
            SUNCodeGenerator.ClassViwer c = new ClassViwer("TSQL", g.ReturnSQLUpdate(), tName + " - (SQL-Update)", tName);
            c.MdiParent = this;
            c.Show();
        }

        private void buttonItem13_Activate(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.Cancel)
                return;
            Classes.File f = new SUNCodeGenerator.Classes.File();
            f.Save(((ClassViwer)this.ActiveMdiChild).TableName, folderBrowserDialog1.SelectedPath, ((ClassViwer)this.ActiveMdiChild).Code, ((ClassViwer)this.ActiveMdiChild).Passvand);
            MessageBox.Show("Successfully...", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void selectProcedureToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string tName = "";
            for (int i = 0; i < TV1.SelectedNode.Text.Length; i++)
            {
                if (TV1.SelectedNode.Text.Substring(i, 1) == " ")
                    tName += "_";
                else
                    tName += TV1.SelectedNode.Text.Substring(i, 1);
            }

            SUNCodeGenerator.Classes.GeneratorClass g = new SUNCodeGenerator.Classes.GeneratorClass(lConnectionString, tName);
            SUNCodeGenerator.ClassViwer c = new ClassViwer("TSQL", g.ReturnSQLSelect(), tName + " - (SQL-Select)", tName);
            c.MdiParent = this;
            c.Show();
        }

        private void menuButtonItem18_Activate(object sender, EventArgs e)
        {

        }


        private void EXEC(string command)
        {
            SqlConnection conn = new SqlConnection(frmLogin.ConnectionString);
            SqlCommand cmd = new SqlCommand(command, conn);

            try
            {
                conn.Open();
                cmd.ExecuteNonQuery();
                txtResult.Text ="Successfuly Query...";
            }
            catch (SqlException ex)
            {
                txtResult.Text = "";
                txtResult.Text = ex.Message;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
                conn.Dispose();
                cmd.Dispose();

            }
        }

        private void buttonItem11_Activate(object sender, EventArgs e)
        {
            EXEC(((ClassViwer)ActiveMdiChild).Code);
        }
    }
}
