using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace SUNCodeGenerator
{
    public partial class frmLogin : Form
    {

        public frmLogin()
        {
            InitializeComponent();
        }

        public static string ConnectionString = "";
        public static string DataBase = "";

        private void frmLogin_Load_1(object sender, EventArgs e)
        {
            txtAuthentication.SelectedIndex = 1;
        }


        private void butTest_Click(object sender, EventArgs e)
        {
            if (txtAuthentication.SelectedIndex == 0)
            {
                txtDB.Items.Clear();
                SqlConnection conn = new SqlConnection("Server=" + txtServer.Text + ";DataBase=Master;UID=" + txtUID.Text + ";PWD=" + txtPWD.Text + ";");
                SqlCommand cmd = new SqlCommand("sp_databases", conn);
                SqlDataReader rdr;
                try
                {
                    conn.Open();
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        txtDB.Items.Add(rdr[0].ToString());
                    }
                    MessageBox.Show("Success...",Text,MessageBoxButtons.OK,MessageBoxIcon.Information);

                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                    cmd.Dispose();
                }
            }
            if (txtAuthentication.SelectedIndex == 1)
            {
                txtDB.Items.Clear();
                SqlConnection conn = new SqlConnection("Server=" + txtServer.Text + ";DataBase=Master;Integrated Security=True;");
                SqlCommand cmd = new SqlCommand("sp_databases", conn);
                SqlDataReader rdr;
                try
                {
                    conn.Open();
                    rdr = cmd.ExecuteReader();

                    while (rdr.Read())
                    {
                        txtDB.Items.Add(rdr[0].ToString());
                    }
                    MessageBox.Show("Success...", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                finally
                {
                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                    conn.Dispose();
                    cmd.Dispose();
                }
            }
        }

        private void butCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void butOk_Click(object sender, EventArgs e)
        {
            if (txtDB.Text != "")
            {

                if (txtAuthentication.SelectedIndex == 0)
                {
                    DataBase = txtDB.Text;
                    ConnectionString = "Server=" + txtServer.Text + ";DataBase=" + txtDB.Text + ";UID=" + txtUID.Text + ";PWD=" + txtPWD.Text + ";";
                }
                else
                {
                    DataBase = txtDB.Text;
                    ConnectionString = "Server=" + txtServer.Text + ";DataBase=" + txtDB.Text + ";Integrated Security=true;";
                }

                this.Hide();
                Form1 f = new Form1(ConnectionString, DataBase);
                f.Show();
            }
        }

        private void txtAuthentication_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtAuthentication.SelectedIndex == 1)
            {
                txtPWD.Enabled = false;
                txtUID.Enabled = false;
            }
            else
            {
                txtPWD.Enabled = true;
                txtUID.Enabled = true;
            }
        }

        private void txtDB_SelectedIndexChanged(object sender, EventArgs e)
        {
            butOk.Enabled = true;
        }
    }
}