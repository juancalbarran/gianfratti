using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace SUNCodeGenerator.Classes
{
    class DataBaseInformation
    {

        private string conStr = "";
        public DataBaseInformation(string ConnectionString)
        {
            conStr = ConnectionString;
        }

        public ArrayList LoadTable()
        {
            SqlConnection conn = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand("SELECT Distinct Table_Name From information_Schema.columns", conn);
            SqlDataReader rdr;
            ArrayList arr = new ArrayList();
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    arr.Add(rdr[0].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "DataBase Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                conn.Dispose();
                cmd.Dispose();
            }
            return arr;
        }


        public ArrayList LoadFileds(string TableName)
        {
            SqlConnection conn = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand("SELECT Column_Name From information_Schema.columns Where Table_Name='" + TableName + "'", conn);
            SqlDataReader rdr;
            ArrayList arr = new ArrayList();
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    arr.Add(rdr[0].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "DataBase Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                conn.Dispose();
                cmd.Dispose();
            }
            return arr;
        }

    }
}
