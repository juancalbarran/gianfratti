using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;

namespace SUNCodeGenerator.Classes
{
    class File
    {
        public void Save(string Name, string Path, string info, string pasvand)
        {
            if (System.IO.File.Exists(Path + "\\" + Name + "." + pasvand))
            {
                if (MessageBox.Show("This File Is Already Exist...\nAre You Want Replace This File?", "File", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Cancel)
                {
                    return;
                }
                else
                {
                    System.IO.File.Delete(Path + "\\" + Name + "." + pasvand);
                }
            }

            FileStream f = new FileStream(Path + "\\" + Name + "." + pasvand, FileMode.CreateNew, FileAccess.Write);
            StreamWriter fso = new StreamWriter(f);
            fso.Write(info);
            fso.Close();
        }
    }
}
