using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace SUNCodeGenerator.Classes
{


    class FiledProperty
    {
        public FiledProperty(string ConnectionString, string DataBase, string Table, string Filed)
        {
            SqlConnection conn = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("SELECT * From information_Schema.columns Where Table_Catalog='" + DataBase + "' AND Table_Name='" + Table + "' AND Column_Name='" + Filed + "'", conn);
            SqlDataReader rdr;
            try
            {
                conn.Open();
                rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    this.TableCatalog = rdr[0].ToString();
                    this.TableSchema = rdr[1].ToString();
                    this.TableName = rdr[2].ToString();
                    this.CollationName = rdr[3].ToString();
                    this.OrdinalPosition = rdr[4].ToString();
                    this.ColumnDefault = rdr[5].ToString();
                    this.IsNullable = rdr[6].ToString();
                    this.DataType = rdr[7].ToString();
                    this.CharacterMixmumLength = rdr[8].ToString();
                    this.CharacterOctetLength = rdr[9].ToString();
                    this.NumericPercision = rdr[10].ToString();
                    this.NumericPercisionRadix = rdr[11].ToString();
                    this.NumericScale = rdr[12].ToString();
                    this.DateTimePercision = rdr[13].ToString();
                    this.CharacterSetCatalog = rdr[14].ToString();
                    this.CharacterSetSchema = rdr[15].ToString();
                    this.CharacterSetName = rdr[16].ToString();
                    this.CollationCatalog = rdr[17].ToString();
                    this.CollationName = rdr[18].ToString();
                    this.DomainCatalog = rdr[19].ToString();
                    this.DomainSchema = rdr[20].ToString();
                    this.DomainName = rdr[21].ToString();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "DataBase Information", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                conn.Dispose();
                cmd.Dispose();
            }

        }

        private string m_TableCatalog;

        public string TableCatalog
        {
            get { return m_TableCatalog; }
            set { m_TableCatalog = value; }
        }

        private string m_TableSchema;

        public string TableSchema
        {
            get { return m_TableSchema; }
            set { m_TableSchema = value; }
        }

        private string m_TableName;

        public string TableName
        {
            get { return m_TableName; }
            set { m_TableName = value; }
        }

        private string m_ColumnName;

        public string ColumnName
        {
            get { return m_ColumnName; }
            set { m_ColumnName = value; }
        }

        private string m_OrdinalPosition;

        public string OrdinalPosition
        {
            get { return m_OrdinalPosition; }
            set { m_OrdinalPosition = value; }
        }

        private string m_ColumnDefault;

        public string ColumnDefault
        {
            get { return m_ColumnDefault; }
            set { m_ColumnDefault = value; }
        }

        private string m_IsNullable;

        public string IsNullable
        {
            get { return m_IsNullable; }
            set { m_IsNullable = value; }
        }

        private string m_DataType;

        public string DataType
        {
            get { return m_DataType; }
            set { m_DataType = value; }
        }

        private string m_CharacterMixmumLength;

        public string CharacterMixmumLength
        {
            get { return m_CharacterMixmumLength; }
            set { m_CharacterMixmumLength = value; }
        }

        private string m_CharacterOctetLength;

        public string CharacterOctetLength
        {
            get { return m_CharacterOctetLength; }
            set { m_CharacterOctetLength = value; }
        }

        private string m_NumericPercision;

        public string NumericPercision
        {
            get { return m_NumericPercision; }
            set { m_NumericPercision = value; }
        }

        private string m_NumericPercisionRadix;

        public string NumericPercisionRadix
        {
            get { return m_NumericPercisionRadix; }
            set { m_NumericPercisionRadix = value; }
        }

        private string m_NumericScale;

        public string NumericScale
        {
            get { return m_NumericScale; }
            set { m_NumericScale = value; }
        }

        private string m_DateTimePercision;

        public string DateTimePercision
        {
            get { return m_DateTimePercision; }
            set { m_DateTimePercision = value; }
        }

        private string m_CharacterSetCatalog;

        public string CharacterSetCatalog
        {
            get { return m_CharacterSetCatalog; }
            set { m_CharacterSetCatalog = value; }
        }

        private string m_CharacterSetSchema;

        public string CharacterSetSchema
        {
            get { return m_CharacterSetSchema; }
            set { m_CharacterSetSchema = value; }
        }

        private string m_CharacterSetName;

        public string CharacterSetName
        {
            get { return m_CharacterSetName; }
            set { m_CharacterSetName = value; }
        }

        private string m_CollationCatalog;

        public string CollationCatalog
        {
            get { return m_CollationCatalog; }
            set { m_CollationCatalog = value; }
        }

        private string m_CollationSchema;

        public string CollationSchema
        {
            get { return m_CollationSchema; }
            set { m_CollationSchema = value; }
        }

        private string m_CollationName;

        public string CollationName
        {
            get { return m_CollationName; }
            set { m_CollationName = value; }
        }

        private string m_DomainCatalog;

        public string DomainCatalog
        {
            get { return m_DomainCatalog; }
            set { m_DomainCatalog = value; }
        }

        private string m_DomainSchema;

        public string DomainSchema
        {
            get { return m_DomainSchema; }
            set { m_DomainSchema = value; }
        }

        private string m_DomainName;

        public string DomainName
        {
            get { return m_DomainName; }
            set { m_DomainName = value; }
        }

    }
}
