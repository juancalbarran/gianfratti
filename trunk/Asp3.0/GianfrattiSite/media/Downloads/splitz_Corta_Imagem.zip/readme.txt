Splitz! Version 1.51
-------------------
(c) Bj�rn Ischo (http://www.b-zone.de)

Splitz! allows you to split any image into rectangular parts and export the resulting images along with the HTML table that puts them back together. This allows webmaster to create for creating mouseover effects and offers an alternative to imagemaps. It supports many images formats and includes smart JPEG compression as well as basic color balancing filters. 

Usage:
------

1. Spliting Images:
Splitz! is really easy to use. Open an image by selecting "Open" from the "File" menu. Now, you can use the mouse to define the cells. Left-clicking the image will bring up a cut line where you clicked, right-clicking switches between horizontal and vertical lines. You can also switch between horizontal and vertical lines by using the buttons above the image. The third button with the rectangle glyph allows you to create a rectangular cell, 4 cut lines will be automatically added.
To edit the cut lines, move your mouse over the desired line. When the cursor changes, you can drag the line by holding the left mouse-button. To remove a line, simple drag it outside of the image. To remove all split lines, select "Clear Splits" from the "Tools" menu.

2. Adjusting JPEG compression:
If JPEG is selected as output format, you can adjust the compression level by clicking on the "JPEG" compression tab and using the slider at the bottom of the page. When you change compression, the right-hand image will show you a preview of the whole (!) compressed image.

3. Exporting image and HTML table:
Finally, when you're done, select "Export" from the "File" menu to save the slices along with the HTML table.

That's it, have fun!

Update Log:
-----------

May 26,2003
Version 1.51:
minor bugfixes to 1.5 (some compability issues with Win2K)

May 23,2003
Version 1.5 (internal release)
- Fixed export bug when having >10 split lines (files would be overwritten)
- Improved JPG preview
- adjustable zoom level for the loupe
- several internal code improvements

January 05,2003:
Version 1.43 A few minor bugfixes (Thanks to Leos Kubin and Matthew Kidd
for bug reports!). Also added option for PNG export.

October 19,2002:
Version 1.42 Fixed some tiny bugs, and added the option to add splitline numerically.
(Thanks to Mat for feedbeack!)

August 25,2002:
Version 1.41 Added option to select between upper/lower case tags and single/double quotes.
(Thanks to Shawn Anderson for his feedback!)

April 19,2002:
Version 1.4 Added optional ALT- and HREF-Information, possibility to edit output code.

March 29,2002:
Version 1.3 Recent Menu, Grids can be saved, several tiny bugfixes.

February 27,2000:
Version 1.2 now saves the slices with the same base name as the table.

February 01,2000:
Version 1.1 (not public released) fixed some minor glitches.

Known Bugs:
-----------

- Splitz does sometimes not paint it's grid correctly if the image size exceeds the visible area.

GIF Support:
------------

- Splitz does NOT support GIF images. The functionality for exporting to GIF is easy, but a company names Unisys holds the patent for the algorithm, and they wanted me to pay them several thousand Dollars for using it in a freeware application, which is of course not acceptable.

Donation:
---------
Altough Splitz is 100% freeware, I wouldn't mind any donation to the further development of Splitz and my other freeware programs. For more info, check:

http://www.b-zone.de/donation.htm



Standard Disclaimer:
--------------------

This software and documentation are protected by copyright law, with all rights reserved. Copyright is held by the author, Bj�rn Ischo. This software is provided "as is". No warranties are made, express or implied, and the author does not warrant that the software will be fit for any particular purpose. The author will in no event be liable for loss of profits, nor incidental or consequential damages. You use this software at your own risk. This software may not be modified, disassembled or reverse engineered in any way without written authorization from the author. This software may be distributed in unmodified form free of charge, provided it is always distributed with this document and no charge is made for it without permission from the author, with the exclusion of reasonable distribution and/or service charges. It is a condition of use that you agree to the above terms. 