<?// Se voc� est� vendo este texto, ent�o seu servidor n�o suporta PHP scripting.
phpinfo();
?>