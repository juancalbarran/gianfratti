<!-- //Courier New,Courier,fixed,
function OnLoad() {
if (document.getElementById) // IE5 NN6
document.getElementById("loading").style.visibility="hidden";
else if (document.layers) // NN4
document.loading.visibility="hidden";
else if (document.all) // IE4
document.all.loading.style.visibility="hidden";
}
-->
