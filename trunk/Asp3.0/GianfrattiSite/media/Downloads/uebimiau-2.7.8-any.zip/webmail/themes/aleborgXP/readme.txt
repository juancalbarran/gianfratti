CyberXP(aka AleborgXP) 1.0
--------------------------------

So far so good!
I think that everything works! If you find a bug 
please report it at www.cyber.nu. 
You are free to use this theme as you like to, BUT
I would be glad if you place a link to cyber.nu.


Support and installation!
---------------------------------
Visit www.cyber.nu 


Changelog
---------------------------------
2002-10-28 
All done!