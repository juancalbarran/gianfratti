
' ASP.NET - Criptografando de Dados 128 Bits
' Neste artigo vou mostrar como voc� pode usar na pr�tica as classes que o .NET Framework oferece para realizar a criptografia.
' Vou come�ar com um exemplo de criptografia de chave privada ou criptografia sim�trica que indica que a mesma chave usada para cifrar � usada para decifrar.
' Iremos usar o algoritimo Rijndael que � o novo DES, definido pelo governo mericano, o Rijndael utiliza uma chave mais forte (256bits).

' A Criptografia tem infinitas usabilidades, isso todos sabem, vou dar apenas um exemplo de como ela poderia ser usada na WEB.
' Todo mundo passa parametros via QueryString (Ex. Usuario.asp?id=1), suponhamos que o usuario fique mudando o ID de usa aplica��o e possa visualizar algum outro registro que n�o fosse o dele,
' isso serio muito ruim, alem de n�o ter a minima seguran�a, ent�o nos ciframos o numero 1 que foi passado como parametro, mas dessa vez cifrado (Ex. Usuario.asp?id=vLyHARA8A0m2SknVd0azxw==)
' Como temos uma chave de at� 32 posi��es, creio eu que seria mais  facil algu�m acertar na sena varias vezes do que acertar essa senha de uma forma aleatoria, sendo que dentro as 32 posi��es nada impede de colocarmos caracteres especiais.
' Podemos tamb�m usar a criptografia para reduzirmos o uso de SQL INJECTION via QueryString.

' Uma outra pratica muito usuavel seria armazenar senhas e outros dados sigilosos dentro do banco de dados,
' neste caso quardariamos a senha cifrada no banco de dados, e no momento que o usuario for se logar temos que cifrar a senha e comparar com a cifra que esta no banco de dados,
' mesmo que alguem obtenha o seu banco de dados, ele nunca descobrira as senhas, pois a chave esta encapsulada dentro de sua aplica��o.

' O.NET Framework fornece as seguintes classes que podem ser usadas para implementar um algoritimo de cifragem usando chave privada:
' 1 - RC2CryptoServiceProvider ( algoritimo RC2 )
' 2 - DESCryptoServiceProvider ( algoritimo DES )
' 3 - TrippleDESCryptoServiceProvider (algoritimo TrippleDES) 
' 4 - RijndaelManaged (algoritimo Rijndael ) -->> Estamos usando este m�todo 

' Vamos criar um pequeno exemplo que ir� cifrar e decifrar dados.
' Por Exemplo:
' Nome a ser cifrado: Fabrizio Gianfratti
' Resultado cifrado: Ia6tgzjAh5wYOCIRJLvxmnoFAPQnVghAnVJxWqyUaME= (Voc� deve mudar esta crifra alterando a variavel ChaveSecreta)
' Resultado decifrado: Fabrizio Gianfratti

' Inicie um novo projeto no VS.NET e escolha um projeto do tipo Asp.net Web Application usando VB.NET.
' Crie um novo WebForm com o nome de Default.asp e siga os passos abaixo.

'   *********************************************************************
'   ***** Autor: Fabrizio Gianfratti                                *****
'   ***** Site: www.gianfratti.com                                  *****
'   ***** Descri��o: Criptografia de chave privada ou criptografia  ***** 
'   *****            sim�trica que indica que a mesma chave usada   *****
'   *****            para cifrar � usada para decifrar o arquivo.   *****
'   *****            C�digo de Criptografia usando o                *****
'   *****            algoritimo Rijndael                            *****
'   *****            O Rijndael � o novo DES, definido pelo governo *****
'   *****            mericano.                                      *****
'   *****            Ele utiliza uma chave mais forte (256bits)     *****
'   ***** Data: 17/05/2006                                          *****
'   *********************************************************************

'   **********************************************************************
'   ***** Use os seguintes imports                                   *****
'   **********************************************************************

Imports System.Security.Cryptography
Imports System.IO
Imports System.Text


Public Class Criptografia
    Inherits System.Web.UI.Page

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    'NOTE: The following placeholder declaration is required by the Web Form Designer.
    'Do not delete or move it.
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region
    '   ********************************************************************
    '   ***** Vari�vel com a sua chave secreta                         *****  
    '   ***** Sempre que o numero for alterado, a cifra ser� diferente *****  
    '   ***** Pode ser passado at� 32 caracteres                       *****
    '   ***** Recomendo n�o deixar essa vari�vel na sua aplica��o, por *****
    '   ***** mais estranho que posso ser existem programas que tem a  *****
    '   ***** capacidade de ler a sua DLL, crie um arquivo texto com a *****
    '   ***** sua chave e proteja essa pasta                           *****
    '   ********************************************************************

    '   ********************************************************************
    '   ***** ATEN��O !!!!  ATEN��O !!!!  ATEN��O !!!! ATEN��O !!!!    *****  
    '   ***** � altamente recomendado que voc� altera a vari�vel       *****  
    '   ***** ChaveSecreta para uma chave de sua escolha.              *****
    '   ********************************************************************

    Private ChaveSecreta As String = "0987612345!@#$%�&*"

    '   *********************************************************************
    '   ***** Definimos uma vari�vel a passamos o texto a ser cifrado   *****
    '   *********************************************************************

    Dim Texto As String = "Fabrizio Gianfratti"

    '   *********************************************************************
    '   ***** No envento Page Load fazemos a chamadas das fun��es       *****
    '   ***** No envento Page Load fazemos a chamadas das fun��es       *****
    '   *********************************************************************

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Response.Write(Cifrar(Texto, ChaveSecreta) & "<br>")
        Response.Write(Decifrar(Cifrar(Texto, ChaveSecreta), ChaveSecreta))
    End Sub


    '   *********************************************************************
    '   ***** Fun��o respons�vel por Cifrar a sua String                *****
    '   ***** Use da seguinte forma:                                    *****
    '   ***** Call Cifrar("Palavra", "SuaChaveSecreta(Ex.2345)")        *****
    '   *********************************************************************

    Private Function Cifrar(ByVal vstrTextToBeEncrypted As String, ByVal vstrEncryptionKey As String) As String

        Dim bytValue() As Byte
        Dim bytKey() As Byte
        Dim bytEncoded() As Byte
        Dim bytIV() As Byte = {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}
        Dim intLength As Integer
        Dim intRemaining As Integer
        Dim objMemoryStream As New MemoryStream
        Dim objCryptoStream As CryptoStream
        Dim objRijndaelManaged As RijndaelManaged


        '   **********************************************************************
        '   ****** Descarta todos os caracteres nulos da palavra a ser cifrada****  
        '   **********************************************************************

        vstrTextToBeEncrypted = TiraCaracteresNulos(vstrTextToBeEncrypted)

        '   **********************************************************************
        '   ******  O valor deve estar dentro da tabela ASCII (i.e., no DBCS chars)
        '   **********************************************************************

        bytValue = Encoding.ASCII.GetBytes(vstrTextToBeEncrypted.ToCharArray)

        intLength = Len(vstrEncryptionKey)

        '   ********************************************************************
        '   ******   A chave cifrada ser� de 256 bits long (32 bytes)     ******
        '   ******   Se for maior que 32 bytes ent�o ser� truncado.       ******
        '   ******   Se for menor que 32 bytes ser� alocado.              ******
        '   ******   Usando upper-case Xs.                                ****** 
        '   ********************************************************************

        If intLength >= 32 Then
            vstrEncryptionKey = Strings.Left(vstrEncryptionKey, 32)
        Else
            intLength = Len(vstrEncryptionKey)
            intRemaining = 32 - intLength
            vstrEncryptionKey = vstrEncryptionKey & Strings.StrDup(intRemaining, "X")
        End If

        bytKey = Encoding.ASCII.GetBytes(vstrEncryptionKey.ToCharArray)

        objRijndaelManaged = New RijndaelManaged

        '   ***********************************************************************
        '   ******  Cria o valor a ser crifrado e depois escreve             ******
        '   ******  Convertido em uma disposi��o do byte                     ******
        '   ***********************************************************************

        Try

            objCryptoStream = New CryptoStream(objMemoryStream, objRijndaelManaged.CreateEncryptor(bytKey, bytIV), CryptoStreamMode.Write)
            objCryptoStream.Write(bytValue, 0, bytValue.Length)

            objCryptoStream.FlushFinalBlock()

            bytEncoded = objMemoryStream.ToArray
            objMemoryStream.Close()
            objCryptoStream.Close()
        Catch

        End Try

        '   ***********************************************************************
        '   ****** Retorna o valor cifrado (convertido de byte para base64 )  *****
        '   ***********************************************************************

        Return Convert.ToBase64String(bytEncoded)

    End Function

    '   *********************************************************************
    '   ***** Fun��o Respons�vel por Decifrar a sua String Cifrada       *****
    '   ***** Use da seguinte forma:                                    *****
    '   ***** Call Decifrar("Palavra", "SuaChaveSecreta(Ex.2345)")      *****
    '   *********************************************************************

    Private Function Decifrar(ByVal vstrStringToBeDecrypted As String, ByVal vstrDecryptionKey As String) As String

        Dim bytDataToBeDecrypted() As Byte
        Dim bytTemp() As Byte
        Dim bytIV() As Byte = {121, 241, 10, 1, 132, 74, 11, 39, 255, 91, 45, 78, 14, 211, 22, 62}
        Dim objRijndaelManaged As New RijndaelManaged
        Dim objMemoryStream As MemoryStream
        Dim objCryptoStream As CryptoStream
        Dim bytDecryptionKey() As Byte

        Dim intLength As Integer
        Dim intRemaining As Integer
        Dim intCtr As Integer
        Dim strReturnString As String = String.Empty
        Dim achrCharacterArray() As Char
        Dim intIndex As Integer

        '   *****************************************************************
        '   ******   Convert base64 cifrada para byte array            ******
        '   ******   Convert base64 cifrada para byte array            ******
        '   *****************************************************************

        bytDataToBeDecrypted = Convert.FromBase64String(vstrStringToBeDecrypted)

        '   ********************************************************************
        '   ******   A chave cifrada sera de 256 bits long (32 bytes)     ******
        '   ******   Se for maior que 32 bytes ent�o ser� truncado.       ******
        '   ******   Se for menor que 32 bytes ser� alocado.              ******
        '   ******   Usando upper-case Xs.                                ****** 
        '   ********************************************************************

        intLength = Len(vstrDecryptionKey)

        If intLength >= 32 Then
            vstrDecryptionKey = Strings.Left(vstrDecryptionKey, 32)
        Else
            intLength = Len(vstrDecryptionKey)
            intRemaining = 32 - intLength
            vstrDecryptionKey = vstrDecryptionKey & Strings.StrDup(intRemaining, "X")
        End If

        bytDecryptionKey = Encoding.ASCII.GetBytes(vstrDecryptionKey.ToCharArray)

        ReDim bytTemp(bytDataToBeDecrypted.Length)

        objMemoryStream = New MemoryStream(bytDataToBeDecrypted)

        '   ***********************************************************************
        '   ******  Escrever o valor decifrado depois que � convertido       ******
        '   ***********************************************************************

        Try

            objCryptoStream = New CryptoStream(objMemoryStream, _
               objRijndaelManaged.CreateDecryptor(bytDecryptionKey, bytIV), _
               CryptoStreamMode.Read)

            objCryptoStream.Read(bytTemp, 0, bytTemp.Length)

            objCryptoStream.FlushFinalBlock()
            objMemoryStream.Close()
            objCryptoStream.Close()

        Catch

        End Try

        '   ***********************************************************************
        '   ******  Retorna o valor decifrado                                ******
        '   ***********************************************************************

        Return TiraCaracteresNulos(Encoding.ASCII.GetString(bytTemp))

    End Function

    '   *********************************************************************
    '   ***** Fun��o responvel por tirar os espa�os em branco da        *****
    '   ***** vari�vel a ser cifrada                                    *****
    '   ***** Esta fun��o � chamada internamente                        *****
    '   *********************************************************************

    Private Function TiraCaracteresNulos(ByVal vstrStringWithNulls As String) As String

        Dim intPosition As Integer
        Dim strStringWithOutNulls As String

        intPosition = 1
        strStringWithOutNulls = vstrStringWithNulls

        Do While intPosition > 0
            intPosition = InStr(intPosition, vstrStringWithNulls, vbNullChar)

            If intPosition > 0 Then
                strStringWithOutNulls = Left$(strStringWithOutNulls, intPosition - 1) & _
                                  Right$(strStringWithOutNulls, Len(strStringWithOutNulls) - intPosition)
            End If

            If intPosition > strStringWithOutNulls.Length Then
                Exit Do
            End If
        Loop

        Return strStringWithOutNulls

    End Function

End Class
