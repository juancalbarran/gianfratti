##############################################################################################
##	License
##############################################################################################



Important! You should carefully read the following end-user license agreement before register 
or install this software program. 
If you do not agree with the terms of this Agreement, you cannot install the software. 

License Agreement

	Shusheng SQL Tool is a domainwebware. 
	

	Domainwebware allows unlimited installations on unlimited processors inside the registered domain.
	Domainwebware allows unlimited users around the globe to use the registered domainwebware. No CALs (Client Access License) needed.
	Shusheng SQL Tool allows any installation of the package connect to unlimited SQL Servers and handle unlimited databases. 
	Domainwebware license covers multiple ports. If you registered yourdomain.com, it automatically covers yourdomain.com:8080.
	Domainwebware license DOES NOT cover sub-domain or parent-domain. If you registered yourdomain.com, it does NOT cover www.yourdomain.com or yourdomain.com.uk.
	Domainwebware DOES NOT allow license-transfer.

	Shusheng SQL Tool is Free to register for Educational Usage.
	Shusheng SQL Tool has up to 80% discount for non-commercial registration.

	Commercial users are encouraged to try out all the features of this package to determine if it meets needs.  
	We want our customers to be totally satisfied with the tool before they make decision to register.
	And that is why: 
	
	websqltool.com does not offer refunds on Shusheng SQL Tool. 

	

        You can modify the customizable file.
	You can not de-compile or decrypt the software program.
        You may re-distribute the program as a whole package without any modification.
        websqltool.com retains the copyright to the source code.


	

THIS SOFTWARE IS PROVIDED 'AS IS' AND WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL THE WEBSQLTOOL.COM,  ITS PARENTS, SUBSIDIARIES, AFFILIATES OR LICENSORS  BE LIABLE FOR  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES  (INCLUDING, BUT NOT LIMITED TO, WORK STOPPAGE, LOSS OF USE, DATA LOSS, DATA CORRUPTION ,  OR PROFITS, COMPUTER FAILURE OR MALFUNCTION, OR ANY AND ALL OTHER COMMERCIAL DAMAGES OR LOSSES.)

Microsoft, Windows, Windows NT, SQL Server 2000, and the Windows logo are trademarks of Microsoft Corporation.
Other company, product, and service names may be trademarks or service marks of others.
  


 
##############################################################################################
##	Installation
##############################################################################################

	1. Shusheng SQL Tool is a pure ASP based web application. No installation needed. 
	2. Just un-zip the zip file to one of your web server directories. ( e.g. C:\Inetpub\wwwroot\sql_tool\ ). 
	3. Open Internet Explorer and type in http://yourDomainName/sql_tool/ in the address bar to start the application. 
	4. For more detail installation information, double cilck file "installation.htm" and follow thie instruction.

##############################################################################################
##	Registration
##############################################################################################

	This is a full featured evaluation package. 
	Users must register after 30 days to avoid interruption of regular usage.

	Shusheng SQL Tool is Free to register for Educational Usage.

	Users are encouraged to try out all the features of this package to determine if it meets needs. 
	We want our customers to be totally satisfied with the tool before they make decision to register.
	
	Registration  can be made at : http://www.websqltool.com/sql_tool/register.htm

2003-6-27