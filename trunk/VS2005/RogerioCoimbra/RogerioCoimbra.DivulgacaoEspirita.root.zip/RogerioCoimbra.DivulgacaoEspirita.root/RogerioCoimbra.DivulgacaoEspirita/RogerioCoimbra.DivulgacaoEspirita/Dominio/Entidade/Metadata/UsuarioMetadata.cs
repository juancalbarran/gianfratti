﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data.Objects.DataClasses;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe Usuario
    /// </summary>
	[DisplayName("Usuário")]
	[Description("Usuários do Sistema.")]
	[DisplayColumn("Nome", "Nome")]
	[ColunasOrdenadas()]
    public class UsuarioMetadata
    {
		/// <summary>
		/// Nome do usuário.
		/// </summary>
		[DisplayName("Nome")]
		[Description("Nome do usuário.")]
		[Required(ErrorMessage = "O campo nome é requerido.")]
		[OrdemColuna(1)]
		public string Nome { get; set; }

		/// <summary>
		/// Login do usuário.
		/// </summary>
		[DisplayName("Login")]
		[Description("Login do usuário.")]
		[Required(ErrorMessage = "O campo login é requerido.")]
		[OrdemColuna(2)]
		public string Login { get; set; }

        /// <summary>
		/// Senha do usuário.
        /// </summary>
		[DisplayName("Senha")]
		[Description("Senha do usuário.")]
		[Required(ErrorMessage = "O campo senha é requerido.")]
		[OrdemColuna(3)]
		[StringLength(12)]
		[DataType(DataType.Password)]
        public string Senha { get; set; }

		/// <summary>
		/// E-mail do usuário.
		/// </summary>
		[DisplayName("E-mail")]
		[Description("E-mail do usuário.")]
		[Required(ErrorMessage = "O campo e-mail é requerido.")]
		[RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "E-mail inválido.")]
		[OrdemColuna(4)]
		public string Email { get; set; }

		/// <summary>
		/// Tipo de usuário.
		/// </summary>
		[DisplayName("Tipo")]
		[Description("Tipo de usuário.")]
		[OrdemColuna(5)]
		public TipoUsuario TipoUsuario { get; set; }

		/// <summary>
		/// Usuário criador do aviso.
		/// </summary>
		[DisplayName("Criador")]
		[Description("Usuário criador do aviso.")]
		[OrdemColuna(6)]
		public Usuario UsuarioCriacao { get; set; }

		/// <summary>
		/// Data de criação do aviso.
		/// </summary>
		[DisplayName("Criado")]
		[Description("Data de criação do aviso.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(7)]
		public DateTime DataCriacao { get; set; }
    }
}
