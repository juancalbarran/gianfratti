﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de matérias.
	/// </summary>
	public class MateriaFabrica
	{
		/// <summary>
		/// Cria uma matérias.
		/// </summary>
		/// <param name="titulo"></param>
		/// <param name="conteudo"></param>
		/// <returns></returns>
		public static Materia Criar(string titulo, string conteudo)
		{
			return new Materia
			{
				Titulo = titulo,
				Conteudo = conteudo
			};
		}
	}
}
