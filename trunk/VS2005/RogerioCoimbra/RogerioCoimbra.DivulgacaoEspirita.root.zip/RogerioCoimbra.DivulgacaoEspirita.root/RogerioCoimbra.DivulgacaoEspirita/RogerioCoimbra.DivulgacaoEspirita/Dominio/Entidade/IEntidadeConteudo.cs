﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
	/// <summary>
	/// Interface que implementa operações padrão de toda entidade que tem conteúdo.
	/// </summary>
	public interface IEntidadeConteudo
	{
		/// <summary>
		/// Conteúdo da informação.
		/// </summary>
		string Conteudo { get; set; }

		/// <summary>
		/// Data de criação do registro.
		/// </summary>
        DateTime DataCriacao { get; }

		/// <summary>
		/// Data da ultima alteração do resgistro.
		/// </summary>
        DateTime? DataUltimaAlteracao { get; }

        /// <summary>
        /// Usuário criador do registro.
        /// </summary>
        Usuario UsuarioCriacao { get; }

        /// <summary>
        /// Usuário que fez a ultima alteração do resgistro.
        /// </summary>
        Usuario UsuarioUltimaAlteracao { get; }
	}
}
