﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Atributo que define se a tabela será suas colunas ordenadas.
    /// </summary>
    public class ColunasOrdenadasAttribute : Attribute
    {

    }
}
