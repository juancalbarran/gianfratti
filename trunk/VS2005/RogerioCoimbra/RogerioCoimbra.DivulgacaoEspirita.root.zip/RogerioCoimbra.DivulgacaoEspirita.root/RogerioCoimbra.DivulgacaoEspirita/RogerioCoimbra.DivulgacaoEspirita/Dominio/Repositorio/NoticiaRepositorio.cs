﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de notícias.
	/// </summary>
	public class NoticiaRepositorio : RepositorioConteudoBase<Noticia>
	{
		/// <summary>
		/// Obtem as ultimas notícias.
		/// </summary>
		public static List<Noticia> ObterCincoUltimas()
		{
			return ObterNUltimos(5);
		}
	}
}
