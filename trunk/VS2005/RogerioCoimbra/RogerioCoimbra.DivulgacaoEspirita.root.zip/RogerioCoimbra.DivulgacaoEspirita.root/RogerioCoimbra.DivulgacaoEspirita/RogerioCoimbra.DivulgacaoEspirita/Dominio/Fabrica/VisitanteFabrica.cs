﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
    /// <summary>
    /// Fabrica de Visitantes.
    /// </summary>
    public class VisitanteFabrica
    {
        /// <summary>
        /// Cria um Vizitante.
        /// </summary>
        /// <param name="nome"></param>
        /// <param name="email"></param>
        /// <returns></returns>
        public static Visitante Criar(string nome, string email)
        {
            return new Visitante
            {
                Nome = nome,
                Email = email
            };
        }
    }
}
