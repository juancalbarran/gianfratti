﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classer Noticia.
    /// </summary>
    [DisplayName("Notícia")]
	[Description("Notícias em geral")]
	[DisplayColumn("DataCriacao", "DataCriacao", true)]
	[ColunasOrdenadas()]
    public class NoticiaMetadata
    {
		/// <summary>
		/// Título da Notícia.
		/// </summary>
		[DisplayName("Título")]
		[Description("Título da Notícia.")]
		[Required(ErrorMessage = "O campo título é requerido.")]
		[OrdemColuna(1)]
		public string Titulo { get; set; }

		/// <summary>
		/// Conteúdo da Notícia.
		/// </summary>
		[DisplayName("Conteúdo")]
		[Description("Conteúdo da Notícia.")]
		[Required(ErrorMessage = "O campo Conteúdo é requerido.")]
		[OrdemColuna(2)]
		public string Conteudo { get; set; }

		/// <summary>
		/// Usuário criador da Notícia.
		/// </summary>
		[DisplayName("Criador")]
		[Description("Usuário criador da Notícia.")]
		[OrdemColuna(3)]
		public Usuario UsuarioCriacao { get; set; }

		/// <summary>
		/// Data de criação da Notícia.
		/// </summary>
		[DisplayName("Criado")]
		[Description("Data de criação da Notícia.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(4)]
		public DateTime DataCriacao { get; set; }

		/// <summary>
		/// Usuário que fez a ultima alteração da Notícia.
		/// </summary>
		[DisplayName("Alterador")]
		[Description("Usuário que fez a ultima alteração da Notícia.")]
		[OrdemColuna(5)]
		public Usuario UsuarioUltimaAlteracao { get; set; }

		/// <summary>
		/// Data da ultima alteração da Notícia.
		/// </summary>
		[DisplayName("Alterado")]
		[Description("Data da ultima alteração da Notícia.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(6)]
		public DateTime? DataUltimaAlteracao { get; set; }
    }
}
