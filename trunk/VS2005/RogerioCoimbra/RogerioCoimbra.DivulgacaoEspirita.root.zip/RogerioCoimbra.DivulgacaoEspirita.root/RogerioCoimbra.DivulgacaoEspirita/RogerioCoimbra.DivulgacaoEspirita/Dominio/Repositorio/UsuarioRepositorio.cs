﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;
using RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.Seguranca;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de usuários.
	/// </summary>
	public class UsuarioRepositorio : RepositorioBase<Usuario>
	{
		/// <summary>
		/// Obtem um Usuário por ID.
		/// </summary>
		public static Usuario ObterPorId(int idUsuario)
		{
            using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
            {
                return ObterPorCondicao(usuario => usuario.idUsuario == idUsuario, objetoContexto).FirstOrDefault();
            }
		}

        /// <summary>
        /// Obtem um usuário por Login e Senha.
        /// </summary>
        /// <param name="login"></param>
        /// <param name="senha"></param>
        /// <returns></returns>
        public static Usuario ObterPorLoginSenha(string login, string senha)
        {
			string senhaHash = CriptografiaSHA256.CalcularHash(senha);
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return ObterPorCondicao(usuario => usuario.Login == login && usuario.Senha == senhaHash, objetoContexto).FirstOrDefault();
			}
        }

		/// <summary>
		/// Obtem um usuário pelo Login.
		/// </summary>
		/// <param name="login"></param>
		/// <returns></returns>
		public static Usuario ObterPorLogin(string login)
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return ObterPorCondicao(usuario => usuario.Login == login, objetoContexto).FirstOrDefault();
			}
		}
	}
}
