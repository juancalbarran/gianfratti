﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de Informações Institucionais.
	/// </summary>
	public class InformacaoInstitucionalFabrica
	{
        /// <summary>
        /// Cria uma Informação Institucional.
        /// </summary>
        /// <param name="titulo"></param>
        /// <param name="conteudo"></param>
        /// <returns></returns>
        public static InformacaoInstitucional Criar(string titulo, string conteudo)
        {
            return new InformacaoInstitucional
            {
                Titulo = titulo,
                Conteudo = conteudo
            };
        }
	}
}
