﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório da relação de usuários e palestras.
	/// </summary>
	public class PalestraUsuarioRepositorio : RepositorioBase<PalestraUsuario>
	{
		/// <summary>
		/// Obtem os usuários(palestrantes) das palestras no mês atual.
		/// </summary>
		public static List<PalestraUsuario> ObterTodasMesAtual()
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return ObterPorCondicao(palestraUsuario => palestraUsuario.DataPalestra.Month == DateTime.Now.Month, objetoContexto).ToList();
			}
		}
	}
}
