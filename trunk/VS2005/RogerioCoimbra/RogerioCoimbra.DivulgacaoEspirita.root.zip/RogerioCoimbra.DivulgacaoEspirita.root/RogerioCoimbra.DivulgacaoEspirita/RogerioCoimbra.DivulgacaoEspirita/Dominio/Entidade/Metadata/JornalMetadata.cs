﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe Jornal
    /// </summary>
    [DisplayName("Jornal")]
	[Description("Publicação do Jornal Local.")]
	[DisplayColumn("DataEdicao", "DataEdicao", true)]
    [ColunasOrdenadas()]
    internal class JornalMetadata
    {
		/// <summary>
		/// Data da Última Edição do Jornal.
		/// </summary>
		[DisplayName("Editado")]
		[Description("Data da Última Edição do Jornal.")]
		[DisplayFormat(DataFormatString = "{0:MM/yyyy}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "O campo Editado é requerido.")]
		[RegularExpression(@"^(0?[1-9]|1[0-2])\/((1[7-9]\d{2})|([2-9]\d{3}))$", ErrorMessage = "Data inválida.")]
		[OrdemColuna(1)]
		public DateTime DataEdicao { get; set; }

        /// <summary>
        /// Assuntos Abordados pelo Jornal.
        /// </summary>
        [DisplayName("Assuntos")]
        [Description("Assuntos Abordados pelo Jornal.")]
		[Required(ErrorMessage = "O campo Assuntos é requerido.")]
        [OrdemColuna(2)]
        public string AssuntosAbordados { get; set; }

		/// <summary>
		/// Usuário criador do aviso.
		/// </summary>
        [DisplayName("Criador")]
        [Description("Usuário criador do aviso.")]
        [OrdemColuna(3)]
        public Usuario UsuarioCriacao { get; set; }

		/// <summary>
		/// Data de Criação do Jornal.
		/// </summary>
        [DisplayName("Criado")]
        [Description("Data de Criação do Jornal.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [OrdemColuna(4)]
        public DateTime DataCriacao { get; set; }
    }
}
