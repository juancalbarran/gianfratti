﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de autores.
	/// </summary>
	public class AutorRepositorio : RepositorioBase<Autor>
	{

	}
}
