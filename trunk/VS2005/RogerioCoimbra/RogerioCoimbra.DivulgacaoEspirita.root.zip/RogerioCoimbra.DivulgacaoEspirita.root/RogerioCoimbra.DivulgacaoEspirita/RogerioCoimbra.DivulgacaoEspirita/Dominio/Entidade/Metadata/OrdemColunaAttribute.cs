﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Atributo que define a ordem dos campos nos templates.
    /// </summary>
    public class OrdemColunaAttribute : Attribute
    {
        /// <summary>
        /// Ordem das colunas.
        /// </summary>
        public int Order { get; private set; }

        /// <summary>
        /// Construtor.
        /// </summary>
        public OrdemColunaAttribute()
        {
            this.Order = int.MaxValue;
        }

        /// <summary>
        /// Construtor.
        /// </summary>
        /// <param name="order"></param>
        public OrdemColunaAttribute(int order)
        {
            this.Order = order;
        }
    }
}
