﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Objects;
using System.Linq;
using System.Web;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
    /// <summary>
    /// DivulgacaoEspiritaEntities
    /// </summary>
    public partial class DivulgacaoEspiritaEntities
    {
        /// <summary>
        /// OnContextCreated
        /// </summary>
        partial void OnContextCreated()
        {
            this.SavingChanges += new EventHandler(OnSavingChanges);
        }

        /// <summary>
        /// OnSavingChanges
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void OnSavingChanges(object sender, EventArgs e)
        {
            //Obtem o gerenciador de estado.
            var objetoContexto = (DivulgacaoEspiritaEntities)sender;
            var stateManager = objetoContexto.ObjectStateManager;
            
            //Obtem as entidades adicionadas e modificadas.
            List<ObjectStateEntry> entidades = new List<ObjectStateEntry>();
            entidades.AddRange(stateManager.GetObjectStateEntries(EntityState.Added));
            entidades.AddRange(stateManager.GetObjectStateEntries(EntityState.Modified));

            //Obtenho o usuário logado da Sessão.
			Usuario usuarioLogado = objetoContexto.Usuario.FirstOrDefault(usuario => usuario.Login == HttpContext.Current.User.Identity.Name);

			if (usuarioLogado == null)
				throw (new DominioException("Erro ao obter o usuario logado."));

            //Preenche dados auxiliares.
            foreach (ObjectStateEntry stateEntryEntity in entidades)
            	if (stateEntryEntity.Entity != null)
            		((IEntidadeBase)stateEntryEntity.Entity).PreencherDadosAuxiliares(usuarioLogado);
        }
    }
}
