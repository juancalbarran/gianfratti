﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de palestras semanais.
	/// </summary>
	public class PalestraSemanalFabrica
	{
		/// <summary>
		/// Cria uma palestra Semanal.
		/// </summary>
        /// <param name="diaSemana"></param>
        /// <param name="titulo"></param>
		/// <param name="horarioInicial"></param>
		/// <param name="horarioFinal"></param>
		/// <returns></returns>
		public static PalestraSemanal Criar(DiaSemana diaSemana, string titulo, DateTime horarioInicial, DateTime horarioFinal)
		{
			return new PalestraSemanal
			{
                DiaSemana = diaSemana,
                Titulo = titulo,
				HorarioInicial = horarioInicial,
				HorarioFinal = horarioFinal,
			};
		}
	}
}
