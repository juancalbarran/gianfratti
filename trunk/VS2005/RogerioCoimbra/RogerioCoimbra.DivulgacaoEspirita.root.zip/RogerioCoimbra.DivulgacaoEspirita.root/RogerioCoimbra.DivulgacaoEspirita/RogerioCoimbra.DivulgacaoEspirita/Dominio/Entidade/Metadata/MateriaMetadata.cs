﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classer Materia.
    /// </summary>
    [DisplayName("Matéria")]
	[Description("Matérias em geral.")]
	[DisplayColumn("DataCriacao", "DataCriacao", true)]
	[ColunasOrdenadas()]
    public class MateriaMetadata
    {
		/// <summary>
		/// Título da Matéria.
		/// </summary>
		[DisplayName("Título")]
		[Description("Título da Matéria.")]
		[Required(ErrorMessage = "O campo título é requerido.")]
		[OrdemColuna(1)]
		public string Titulo { get; set; }

		/// <summary>
		/// Conteúdo da Matéria.
		/// </summary>
		[DisplayName("Conteúdo")]
		[Description("Conteúdo da Matéria.")]
		[Required(ErrorMessage = "O campo Conteúdo é requerido.")]
		[OrdemColuna(2)]
		public string Conteudo { get; set; }

		/// <summary>
		/// Usuário criador da Matéria.
		/// </summary>
		[DisplayName("Criador")]
		[Description("Usuário criador da Matéria.")]
		[OrdemColuna(3)]
		public Usuario UsuarioCriacao { get; set; }

		/// <summary>
		/// Data de criação da Matéria.
		/// </summary>
		[DisplayName("Criado")]
		[Description("Data de criação da Matéria.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(4)]
		public DateTime DataCriacao { get; set; }

		/// <summary>
		/// Usuário que fez a ultima alteração da Matéria.
		/// </summary>
		[DisplayName("Alterador")]
		[Description("Usuário que fez a ultima alteração da Matéria.")]
		[OrdemColuna(5)]
		public Usuario UsuarioUltimaAlteracao { get; set; }

		/// <summary>
		/// Data da ultima alteração da Matéria.
		/// </summary>
		[DisplayName("Alterado")]
		[Description("Data da ultima alteração da Matéria.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(6)]
		public DateTime? DataUltimaAlteracao { get; set; }
    }
}
