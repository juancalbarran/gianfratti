﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
    /// <summary>
    /// Parte da classe Frase.
    /// </summary>
    [MetadataType(typeof(Metadata.FraseMetadata))]
	public partial class Frase : IEntidadeConteudo, IEntidadeBase
	{
        #region IEntidadeBase Members
        /// <summary>
        /// Preencher dados Auxiliares.
        /// </summary>
        /// <param name="usuarioLogado"></param>
        void IEntidadeBase.PreencherDadosAuxiliares(Usuario usuarioLogado)
        {
			DateTime dataAtual = DateTime.Now;

			if (EntityState == EntityState.Added)
			{
				DataCriacao = dataAtual;
				UsuarioCriacao = usuarioLogado;
			}
			else
			{
				DataUltimaAlteracao = dataAtual;

				if (UsuarioUltimaAlteracao == null || UsuarioUltimaAlteracao.Login != usuarioLogado.Login)
					UsuarioUltimaAlteracao = usuarioLogado;
			}
        }
        #endregion
	}
}
