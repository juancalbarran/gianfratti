﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de notícias.
	/// </summary>
	public class NoticiaFabrica
	{
		/// <summary>
		/// Cria uma notícias.
		/// </summary>
		/// <param name="titulo"></param>
		/// <param name="conteudo"></param>
		/// <returns></returns>
		public static Noticia Criar(string titulo, string conteudo)
		{
			return new Noticia
			{
				Titulo = titulo,
				Conteudo = conteudo
			};
		}
	}
}
