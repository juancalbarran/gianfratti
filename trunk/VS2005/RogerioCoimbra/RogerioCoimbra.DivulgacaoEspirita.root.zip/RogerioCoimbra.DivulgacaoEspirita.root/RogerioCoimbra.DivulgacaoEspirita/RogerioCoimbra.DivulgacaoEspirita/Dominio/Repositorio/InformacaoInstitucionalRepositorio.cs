﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de informações institucionais.
	/// </summary>
	public class InformacaoInstitucionalRepositorio : RepositorioConteudoBase<InformacaoInstitucional>
	{
		/// <summary>
		/// Obtem uma informação institucional por ID.
		/// </summary>
		public static InformacaoInstitucional ObterPorId(int idInformacaoInstitucional)
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return ObterPorCondicao(informacaoInstitucional => informacaoInstitucional.idInformacaoInstitucional == idInformacaoInstitucional, objetoContexto).FirstOrDefault();
			}
		}
	}
}
