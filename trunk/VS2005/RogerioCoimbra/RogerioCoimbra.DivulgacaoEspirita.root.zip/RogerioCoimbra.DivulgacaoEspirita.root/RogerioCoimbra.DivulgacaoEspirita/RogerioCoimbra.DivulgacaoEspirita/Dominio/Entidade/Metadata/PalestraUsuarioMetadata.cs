﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe PalestraUsuario
    /// </summary>
    [DisplayName("Palestras e Usuários")]
	[Description("Palestras que forão ou que iram ser ministradas pelos usuários.")]
	[DisplayColumn("DataPalestra", "DataPalestra", true)]
	[ColunasOrdenadas()]
    public class PalestraUsuarioMetadata
    {
		/// <summary>
		/// Palestra que o usuário irá ministrar.
		/// </summary>
		[DisplayName("Palestra")]
		[Description("Palestra que o usuário irá ministrar.")]
		[OrdemColuna(1)]
		public PalestraSemanal PalestraSemanal { get; set; }

		/// <summary>
		/// Usuário que irá ministrar a palestra.
		/// </summary>
		[DisplayName("Usuário")]
		[Description("Usuário que irá ministrar a palestra.")]
		[OrdemColuna(2)]
		public Usuario Usuario { get; set; }

		/// <summary>
		/// Data da Palestra.
		/// </summary>
		[DisplayName("Data")]
		[Description("Data da Palestra.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "O campo data é requerido.")]
		[OrdemColuna(3)]
		public DateTime DataPalestra { get; set; }
    }
}
