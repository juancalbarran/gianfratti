﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de frases.
	/// </summary>
	public class FraseFabrica
	{
		/// <summary>
		/// Cria uma frase.
		/// </summary>
        /// <param name="autor"></param>
		/// <param name="conteudo"></param>
		/// <returns></returns>
		public static Frase Criar(Autor autor, string conteudo)
		{
			return new Frase
			{
                Autor = autor,
				Conteudo = conteudo
			};
		}
	}
}
