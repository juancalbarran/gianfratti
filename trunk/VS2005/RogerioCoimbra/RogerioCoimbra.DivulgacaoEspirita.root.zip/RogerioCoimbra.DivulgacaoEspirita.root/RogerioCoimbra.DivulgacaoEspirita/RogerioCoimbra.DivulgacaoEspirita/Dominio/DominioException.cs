﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio
{
	/// <summary>
	/// Exceção que trata as regras de negocio do Domínio.
	/// </summary>
	[Serializable]
	public class DominioException : Exception
	{
		/// <summary>
		/// 
		/// </summary>
		public DominioException() { }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		public DominioException(string message)
			: base(message) { }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="message"></param>
		/// <param name="inner"></param>
		public DominioException(string message, Exception inner)
			: base(message, inner) { }

		/// <summary>
		/// 
		/// </summary>
		/// <param name="info"></param>
		/// <param name="context"></param>
		protected DominioException(SerializationInfo info, StreamingContext context)
			: base(info, context) { }
	}
}
