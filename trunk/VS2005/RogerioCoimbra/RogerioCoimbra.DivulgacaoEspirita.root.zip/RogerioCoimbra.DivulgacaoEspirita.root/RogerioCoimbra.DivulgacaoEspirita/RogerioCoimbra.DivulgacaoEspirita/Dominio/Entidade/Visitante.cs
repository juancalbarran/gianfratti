﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
    /// <summary>
    /// Parte da classe Visitante
    /// </summary>
    [MetadataType(typeof(Metadata.VisitanteMetadata))]
    public partial class Visitante : IEntidadeBase
    {
        #region IEntidadeBase Members
        /// <summary>
        /// Preencher dados Auxiliares.
        /// </summary>
        /// <param name="usuarioLogado"></param>
        void IEntidadeBase.PreencherDadosAuxiliares(Usuario usuarioLogado)
        {
			if (this.EntityState == EntityState.Added)
			{
				this.DataCriacao = DateTime.Now;
			}
        }
        #endregion
    }
}
