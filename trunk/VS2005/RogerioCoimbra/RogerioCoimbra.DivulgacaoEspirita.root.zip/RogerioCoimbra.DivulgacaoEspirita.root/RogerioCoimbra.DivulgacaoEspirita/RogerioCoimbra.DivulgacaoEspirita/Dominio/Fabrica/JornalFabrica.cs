﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de jornais.
	/// </summary>
	public class JornalFabrica
	{
		/// <summary>
		/// Cria um Jornal.
		/// </summary>
		/// <param name="assuntosAbordados"></param>
		/// <returns></returns>
		public static Jornal Criar(string assuntosAbordados)
		{
			return new Jornal
			{
				AssuntosAbordados = assuntosAbordados
			};
		}
	}
}
