﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de frases.
	/// </summary>
	public class FraseRepositorio : RepositorioConteudoBase<Frase>
	{
		//Instancia do gerador de números aleatórios.
		private static Random random = new Random();

		/// <summary>
		/// Obtem um frase aleatoriamente.
		/// </summary>
		public static Frase ObterAleatoria()
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				//Obtem uma consulta com todas as frases.
				IQueryable<Frase> frases = ObterTodos(objetoContexto);

				//Obtem um número Aleatório de 0 até o total de frases menos 1.
				int numeroAleatorio = random.Next(frases.Count() - 1);

				//Retorna o primeiro registro apos o número Aleatório.
				return frases.OrderBy(frase => frase.idFrase).Skip(numeroAleatorio).FirstOrDefault();
			}
		}
	}
}
