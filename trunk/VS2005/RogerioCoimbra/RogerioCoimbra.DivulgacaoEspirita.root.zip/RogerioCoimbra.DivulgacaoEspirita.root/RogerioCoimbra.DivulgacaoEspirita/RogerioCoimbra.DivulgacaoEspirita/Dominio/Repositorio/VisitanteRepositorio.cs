﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
    /// <summary>
    /// Repositório de Visitantes.
    /// </summary>
    public class VisitanteRepositorio : RepositorioBase<Visitante>
    {
		/// <summary>
		/// Insere um visitante.
		/// </summary>
		/// <param name="visitante"></param>
		public new static void Inserir(Visitante visitante)
		{
			try
			{
				RepositorioBase<Visitante>.Inserir(visitante);
			}
			catch
			{
				if (ExistePorEmail(visitante))
					throw(new DominioException("E-mail já foi cadastrado."));
				else
					throw;
			}
		}

		/// <summary>
		/// Verifica se o e-mail existe na base.
		/// </summary>
		/// <param name="visitante"></param>
		/// <returns></returns>
		public static Boolean ExistePorEmail(Visitante visitante)
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return ObterTodos(objetoContexto)
					.Any(n => n.Email == visitante.Email);
			}
		}
    }
}
