﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.Seguranca;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
    /// <summary>
    /// Parte da classe Usuario
    /// </summary>
    [MetadataType(typeof(Metadata.UsuarioMetadata))]
    public partial class Usuario : IEntidadeBase
    {
        #region IEntidadeBase Members
        /// <summary>
        /// Preencher dados Auxiliares.
        /// </summary>
        /// <param name="usuarioLogado"></param>
        void IEntidadeBase.PreencherDadosAuxiliares(Usuario usuarioLogado)
        {
            if (this.EntityState == EntityState.Added)
            {
                this.DataCriacao = DateTime.Now;
                this.UsuarioCriacao = usuarioLogado;
            }

			Senha = CriptografiaSHA256.CalcularHash(Senha);
        }
        #endregion
    }
}
