﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de avisos.
	/// </summary>
	public class AvisoFabrica
	{
		/// <summary>
		/// Cria um aviso.
		/// </summary>
		/// <param name="titulo"></param>
		/// <param name="conteudo"></param>
		/// <returns></returns>
		public static Aviso Criar(string titulo, string conteudo)
		{
			return new Aviso
			{
				Titulo = titulo,
				Conteudo = conteudo,
			};
		}
	}
}
