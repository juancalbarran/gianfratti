﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de usuários.
	/// </summary>
	public class UsuarioFabrica
	{
		/// <summary>
		/// Cria um usuário.
		/// </summary>
		/// <param name="tipoUsuario"></param>
		/// <param name="login"></param>
		/// <param name="nome"></param>
        /// <param name="senha"></param>
        /// <param name="email"></param>
		/// <returns></returns>
		public static Usuario Criar(TipoUsuario tipoUsuario, string login, string nome, string senha, string email)
		{
			return new Usuario
			{
				TipoUsuario = tipoUsuario,
				Login = login,
				Nome = nome,
                Senha = senha,
                Email = email,
			};
		}
	}
}
