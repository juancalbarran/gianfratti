﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Data.Objects.DataClasses;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe Autor
    /// </summary>
    [DisplayName("Autor")]
	[Description("Autores das frases.")]
	[DisplayColumn("Nome", "Nome")]
    [ColunasOrdenadas()]
    internal class AutorMetadata
    {
        /// <summary>
		/// Nome do Autor.
        /// </summary>
        [DisplayName("Nome")]
        [Description("Nome do Autor.")]
		[Required(ErrorMessage = "O campo Nome é requerido.")]
        [OrdemColuna(1)]
        public string Nome { get; set; }

        /// <summary>
		/// Observação sobre o Autor.
        /// </summary>
        [DisplayName("Observação")]
        [Description("Observação sobre o Autor.")]
        [OrdemColuna(2)]
        public string Observacao { get; set; }

        /// <summary>
		/// Data de Nascimento do Autor.
        /// </summary>
        [DisplayName("Nascimento")]
        [Description("Data de Nascimento do Autor.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "O campo Nascimento é requerido.")]
		[RegularExpression(@"^((((31\/(0?[13578]|1[02]))|((29|30)\/(0?[1,3-9]|1[0-2])))\/(1[6-9]|[2-9]\d)?\d{2})|(29\/0?2\/(((1[6-9]|[2-9]\d)?(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))|(0?[1-9]|1\d|2[0-8])\/((0?[1-9])|(1[0-2]))\/((1[6-9]|[2-9]\d)?\d{2}))$", ErrorMessage = "Data inválida.")]
        [OrdemColuna(3)]
        public DateTime AnoNascimento { get; set; }

        /// <summary>
		/// Data de Falecimento do Autor.
        /// </summary>
        [DisplayName("Falecimento")]
        [Description("Data de Falecimento do Autor.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
		[RegularExpression(@"^((((31\/(0?[13578]|1[02]))|((29|30)\/(0?[1,3-9]|1[0-2])))\/(1[6-9]|[2-9]\d)?\d{2})|(29\/0?2\/(((1[6-9]|[2-9]\d)?(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))|(0?[1-9]|1\d|2[0-8])\/((0?[1-9])|(1[0-2]))\/((1[6-9]|[2-9]\d)?\d{2}))$", ErrorMessage = "Data inválida.")]
        [OrdemColuna(4)]
        public DateTime? AnoFalecimento { get; set; }
    }
}
