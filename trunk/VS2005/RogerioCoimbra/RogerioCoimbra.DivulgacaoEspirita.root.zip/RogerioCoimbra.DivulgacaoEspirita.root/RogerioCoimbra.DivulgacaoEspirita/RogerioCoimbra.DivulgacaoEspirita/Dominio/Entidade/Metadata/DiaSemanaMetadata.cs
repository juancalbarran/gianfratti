﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe DiaSemana
    /// </summary>
	[ScaffoldTable(false)]
	[DisplayName("Dia da Semana")]
    internal class DiaSemanaMetadata
    {
    }
}
