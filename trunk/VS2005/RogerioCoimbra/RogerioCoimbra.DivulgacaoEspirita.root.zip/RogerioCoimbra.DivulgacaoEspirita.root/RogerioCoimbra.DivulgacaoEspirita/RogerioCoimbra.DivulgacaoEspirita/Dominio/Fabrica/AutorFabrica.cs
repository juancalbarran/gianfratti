﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica de autores.
	/// </summary>
	public class AutorFabrica
	{
		/// <summary>
		/// Cria um Autor.
		/// </summary>
		/// <param name="nome"></param>
		/// <param name="anoNascimento"></param>
		/// <returns></returns>
		public static Autor Criar(string nome, DateTime anoNascimento)
		{
			return new Autor
			{
				Nome = nome,
				AnoNascimento = anoNascimento
			};
		}
	}
}
