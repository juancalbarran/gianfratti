﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica
{
	/// <summary>
	/// Fabrica da relação de usuários e palestras.
	/// </summary>
	public class PalestraUsuarioFabrica
	{
		/// <summary>
		/// Cria uma relação de usuário(Palestrante) com palestra.
		/// </summary>
		/// <param name="palestraSemanal"></param>
		/// <param name="usuario"></param>
		/// <param name="dataPalestra"></param>
		/// <returns></returns>
		public static PalestraUsuario Criar(PalestraSemanal palestraSemanal, Usuario usuario, DateTime dataPalestra)
		{
			return new PalestraUsuario
			{
				PalestraSemanal = palestraSemanal,
				Usuario = usuario,
				DataPalestra = dataPalestra
			};
		}
	}
}
