﻿using System;
using System.Collections.Generic;
using System.Data.Objects.DataClasses;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	///  Repositório base para entidades que implementam a interface IEntidadeConteudo, contém as operações básicas de um repositório.
	/// </summary>
	public abstract class RepositorioConteudoBase<Entidade> : RepositorioBase<Entidade> where Entidade : EntityObject, IEntidadeConteudo
	{
		#region Protected
		/// <summary>
		/// Obtém as N ultimas entidade.
		/// </summary>
		protected static List<Entidade> ObterNUltimos(int registroRetornado)
		{
			using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
			{
				return
					(
					from entidade in ObterTodos(objetoContexto)
					orderby
						entidade.DataUltimaAlteracao descending,
						entidade.DataCriacao descending
					select entidade
					)
					.Take(registroRetornado)
					.ToList();
			}
		}
		#endregion
	}
}
