﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe Visitante.
    /// </summary>
    [DisplayName("Visitante")]
	[Description("Visitantes cadastrados.")]
	[DisplayColumn("DataCriacao", "DataCriacao", true)]
	[ColunasOrdenadas()]
    public class VisitanteMetadata
    {
		/// <summary>
		/// Nome do Visitante.
		/// </summary>
		[DisplayName("Nome")]
		[Description("Nome do Visitante.")]
		[Required(ErrorMessage = "O campo nome é requerido.")]
		[OrdemColuna(1)]
		public string Nome { get; set; }

		/// <summary>
		/// Email do Visitante.
		/// </summary>
		[DisplayName("Email")]
		[Description("Email do Visitante.")]
		[Required(ErrorMessage = "O campo e-mail é requerido.")]
		[RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*", ErrorMessage = "E-mail inválido.")]
		[OrdemColuna(2)]
		public string Email { get; set; }

		/// <summary>
		/// Data de criação do aviso.
		/// </summary>
		[DisplayName("Criado")]
		[Description("Data de criação do aviso.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
		[OrdemColuna(3)]
		public DateTime DataCriacao { get; set; }
    }
}

