﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de palestras semanais.
	/// </summary>
	public class PalestraSemanalRepositorio : RepositorioBase<PalestraSemanal>
	{

	}
}
