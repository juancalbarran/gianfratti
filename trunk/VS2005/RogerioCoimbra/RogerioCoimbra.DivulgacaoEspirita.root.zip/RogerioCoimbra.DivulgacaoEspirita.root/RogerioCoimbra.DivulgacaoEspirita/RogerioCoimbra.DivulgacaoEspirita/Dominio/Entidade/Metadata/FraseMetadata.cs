﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe Frase.
    /// </summary>
    [DisplayName("Frase")]
	[Description("Frases em geral.")]
	[DisplayColumn("DataCriacao", "DataCriacao", true)]
    [ColunasOrdenadas()]
    internal class FraseMetadata
    {
		/// <summary>
		/// Conteúdo do aviso.
		/// </summary>
		[DisplayName("Conteúdo")]
		[Description("Conteúdo do aviso.")]
		[Required(ErrorMessage = "O campo Conteúdo é requerido.")]
		[OrdemColuna(1)]
		public string Conteudo { get; set; }

		/// <summary>
		/// Autor da Frase.
		/// </summary>
		[DisplayName("Autor")]
		[Description("Autor da Frase.")]
		[OrdemColuna(2)]
		public Autor Autor { get; set; }

        /// <summary>
		/// Usuário criador do aviso.
        /// </summary>
        [DisplayName("Criador")]
        [Description("Usuário criador do aviso.")]
        [OrdemColuna(3)]
        public Usuario UsuarioCriacao { get; set; }

        /// <summary>
		/// Data de criação do aviso.
        /// </summary>
        [DisplayName("Criado")]
        [Description("Data de criação do aviso.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
        [OrdemColuna(4)]
        public DateTime DataCriacao { get; set; }

        /// <summary>
		/// Usuário que fez a ultima alteração do aviso.
        /// </summary>
        [DisplayName("Alterador")]
        [Description("Usuário que fez a ultima alteração do aviso.")]
        [OrdemColuna(5)]
        public Usuario UsuarioUltimaAlteracao { get; set; }

        /// <summary>
		/// Data da ultima alteração do aviso.
        /// </summary>
        [DisplayName("Alterado")]
        [Description("Data da ultima alteração do aviso.")]
		[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy HH:mm}", ApplyFormatInEditMode = true)]
        [OrdemColuna(6)]
        public DateTime? DataUltimaAlteracao { get; set; }
    }
}
