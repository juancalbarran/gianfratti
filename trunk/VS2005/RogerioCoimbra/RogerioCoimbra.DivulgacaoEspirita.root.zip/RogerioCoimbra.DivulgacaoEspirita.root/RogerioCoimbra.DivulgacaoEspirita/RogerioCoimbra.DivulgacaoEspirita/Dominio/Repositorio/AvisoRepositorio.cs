﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de Avisos.
	/// </summary>
	public class AvisoRepositorio : RepositorioConteudoBase<Aviso>
	{
		/// <summary>
		/// Obtem os dois ultimos avisos.
		/// </summary>
		public static List<Aviso> ObterDoisUltimos()
		{
			return ObterNUltimos(2);
		}
	}
}
