﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de matérias.
	/// </summary>
	public class MateriaRepositorio : RepositorioConteudoBase<Materia>
	{
		/// <summary>
		/// Obtem as ultimas notícias.
		/// </summary>
		public static List<Materia> ObterCincoUltimas()
		{
			return ObterNUltimos(5);
		}
	}
}
