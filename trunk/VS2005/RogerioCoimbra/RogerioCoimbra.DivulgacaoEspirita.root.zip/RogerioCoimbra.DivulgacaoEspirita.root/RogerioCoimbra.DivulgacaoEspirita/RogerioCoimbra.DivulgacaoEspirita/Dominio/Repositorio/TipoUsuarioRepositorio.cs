﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio
{
	/// <summary>
	/// Repositório de Tipos de Usuário.
	/// </summary>
	public class TipoUsuarioRepositorio : RepositorioBase<TipoUsuario>
	{
		/// <summary>
		/// Obtem um Tipo de Usuário por ID.
		/// </summary>
		public static TipoUsuario ObterPorId(int idTipoUsuario)
		{
            using (DivulgacaoEspiritaEntities objetoContexto = ObterContexto())
            {
                return ObterPorCondicao(tipoUsuario => tipoUsuario.idTipoUsuario == idTipoUsuario, objetoContexto).FirstOrDefault();
            }
		}
	}
}
