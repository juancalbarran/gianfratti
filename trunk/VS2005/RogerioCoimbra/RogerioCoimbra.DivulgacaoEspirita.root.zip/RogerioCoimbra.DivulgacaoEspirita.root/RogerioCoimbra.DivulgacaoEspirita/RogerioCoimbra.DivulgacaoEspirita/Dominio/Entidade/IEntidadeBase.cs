﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade
{
    /// <summary>
    /// Implementa o comportamento padrão de todas as entidades. 
    /// </summary>
    internal interface IEntidadeBase
    {
        /// <summary>
        /// Preencher dados Auxiliares.
        /// </summary>
        /// <param name="usuarioLogado"></param>
        void PreencherDadosAuxiliares(Usuario usuarioLogado);
    }
}
