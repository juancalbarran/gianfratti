﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Data.Objects.DataClasses;

namespace RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata
{
    /// <summary>
    /// Metadado da classe PalestraSemanal
    /// </summary>
    [DisplayName("Palestra Semanal")]
	[Description("Palestras em geral.")]
	[DisplayColumn("Titulo", "Titulo")]
	[ColunasOrdenadas()]
    public class PalestraSemanalMetadata
    {
		/// <summary>
		/// Título da Matéria.
		/// </summary>
		[DisplayName("Título")]
		[Description("Título da Matéria.")]
		[Required(ErrorMessage = "O campo título é requerido.")]
		[OrdemColuna(1)]
		public string Titulo { get; set; }

		/// <summary>
		/// Dia da Semana da Palestra Semanal.
		/// </summary>
		[DisplayName("Dia da Semana")]
		[Description("Dia da Semana da Palestra Semanal.")]
		[OrdemColuna(2)]
		public DiaSemana DiaSemana { get; set; }

		/// <summary>
		/// Descrição da Palestra Semanal.
		/// </summary>
		[DisplayName("Descrição")]
		[Description("Descrição da Palestra Semanal.")]
		[OrdemColuna(3)]
		public string Descricao { get; set; }

		/// <summary>
		/// Horário Inicial da Palestra Semanal.
		/// </summary>
		[DisplayName("Inicio")]
		[Description("Horário Inicial da Palestra Semanal.")]
		[DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "O campo inicio é requerido.")]
		//[RegularExpression(@"^([0-1]?\d|2[0-3]):([0-5]\d)$", ErrorMessage = "Horário inválido.")]
		[OrdemColuna(4)]
		[UIHint("Time")]
		public DateTime HorarioInicial { get; set; }

		/// <summary>
		/// Horário final da Palestra Semanal.
		/// </summary>
		[DisplayName("Fim")]
		[Description("Horário final da Palestra Semanal.")]
		[DisplayFormat(DataFormatString = "{0:HH:mm}", ApplyFormatInEditMode = true)]
		[Required(ErrorMessage = "O campo fim é requerido.")]
		//[RegularExpression(@"^([0-1]?\d|2[0-3]):([0-5]\d)$", ErrorMessage = "Horário inválido.")]
		[OrdemColuna(5)]
		[UIHint("Time")]
		public DateTime HorarioFinal { get; set; }
    }
}
