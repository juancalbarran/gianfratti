﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.DynamicData;

namespace RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.MetodosEstendidos
{
	/// <summary>
	/// MetaTable Extension
	/// </summary>
	public static class MetaTableExtension
	{
		/// <summary>
		/// GetAttribute
		/// </summary>
		/// <typeparam name="T"></typeparam>
		/// <param name="table"></param>
		/// <returns></returns>
		public static T GetAttribute<T>(this MetaTable table) where T : Attribute
		{
			return table.Attributes.OfType<T>().FirstOrDefault();
		}
	}
}
