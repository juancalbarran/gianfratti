﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura
{
    /// <summary>
    /// Exceção que trata as regras de negocio da Infra-Estrutura.
    /// </summary>
    [Serializable]
    public class InfraEstruturaException : Exception
    {
        /// <summary>
        /// 
        /// </summary>
        public InfraEstruturaException() { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public InfraEstruturaException(string message)
            : base(message) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="inner"></param>
        public InfraEstruturaException(string message, Exception inner)
            : base(message, inner) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected InfraEstruturaException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}
