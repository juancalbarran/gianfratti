﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.Seguranca
{
    /// <summary>
    /// Implementa a classe SHA256CryptoServiceProvider.
    /// </summary>
    public static class CriptografiaSHA256
    {
        private static SHA256CryptoServiceProvider sha256 = new SHA256CryptoServiceProvider();

        /// <summary>
        /// Calcula o Hash baseado no algoritmo SHA256.
        /// </summary>
        /// <param name="entrada"></param>
        /// <returns></returns>
        public static string CalcularHash(string entrada)
        {
            string saida = Encoding.Default.GetString(sha256.ComputeHash(Encoding.Default.GetBytes(entrada)));

            if (saida.Length != (sha256.HashSize/8))
                throw (new InfraEstruturaException("Erro ao calcular o Hash."));

            return @saida;
        }
    }
}
