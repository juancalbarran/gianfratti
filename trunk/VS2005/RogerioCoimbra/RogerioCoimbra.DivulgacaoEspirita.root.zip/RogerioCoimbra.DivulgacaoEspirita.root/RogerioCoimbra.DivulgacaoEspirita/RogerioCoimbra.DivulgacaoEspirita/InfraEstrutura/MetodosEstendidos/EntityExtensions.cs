﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Objects.DataClasses;

namespace RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.MetodosEstendidos
{
	/// <summary>
	/// Entity extensions
	/// </summary>
	public static class EntityExtensions
	{
		/// <summary>
		/// Ensures that entity referenced by <paramref name="entityReference"/> is loaded.
		/// </summary>
		public static void EnsureLoad<TEntity>(this EntityReference<TEntity> entityReference) where TEntity : EntityObject
		{
			if (!entityReference.IsLoaded)
			{
				entityReference.Load();
			}
		}

		/// <summary>
		/// Ensures that entity collection is loaded.
		/// </summary>
		public static void EnsureLoad<TEntity>(this EntityCollection<TEntity> entityCollection) where TEntity : EntityObject
		{
			if (!entityCollection.IsLoaded)
			{
				entityCollection.Load();
			}
		}
	}
}
