﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Pagina
{
    public partial class Logon : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ControleLogin_Authenticate(object sender, AuthenticateEventArgs e)
        {
            //Obtem o usuário logado.
            Usuario usuarioLogado = UsuarioRepositorio.ObterPorLoginSenha(ControleLogin.UserName, ControleLogin.Password);

            //Usuário esta autenticado.
            if (usuarioLogado != null)
            {
                //Notifica ao Controle de Login.
                e.Authenticated = true;

                //Redireciona para a página que fez a requisição de Autenticação.
                //Cria o Cookie de persistência.
				FormsAuthentication.RedirectFromLoginPage(ControleLogin.UserName, true);
            }
            
        }
    }
}
