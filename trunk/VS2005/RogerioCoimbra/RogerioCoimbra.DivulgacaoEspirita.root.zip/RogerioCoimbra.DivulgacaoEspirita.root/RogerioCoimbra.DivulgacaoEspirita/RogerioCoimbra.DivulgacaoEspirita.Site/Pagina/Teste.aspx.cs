﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Pagina
{
	public partial class Teste : System.Web.UI.Page
	{
		private TipoUsuario tipoUsuario;

		protected void Page_Load(object sender, EventArgs e)
		{
			tipoUsuario = TipoUsuarioRepositorio.ObterPorId(1);
		}

		protected void ButtonCriar_Click(object sender, EventArgs e)
		{
			Usuario usuario = UsuarioFabrica.Criar(tipoUsuario, "XX", "xx", "aa", "aa");
		}

		protected void ButtonObter_Click(object sender, EventArgs e)
		{
			Usuario usuario = UsuarioRepositorio.ObterPorId(1);
		}
    }
}
