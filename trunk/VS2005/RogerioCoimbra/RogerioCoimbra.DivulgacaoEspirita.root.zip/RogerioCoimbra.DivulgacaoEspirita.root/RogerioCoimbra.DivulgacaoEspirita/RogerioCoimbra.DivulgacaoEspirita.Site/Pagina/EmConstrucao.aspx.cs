﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Fabrica;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Repositorio;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Pagina
{
	public partial class EmConstrucao : System.Web.UI.Page
	{
		/// <summary>
		/// Evento Page_Load
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void Page_Load(object sender, EventArgs e)
		{

		}

		/// <summary>
		/// Evento ButtonEnviar_Click
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		protected void ButtonEnviar_Click(object sender, ImageClickEventArgs e)
		{
			try
			{
				VisitanteRepositorio.Inserir(
					VisitanteFabrica.Criar(
						TextBoxNome.Text,
						TextBoxEmail.Text
					)
				);

				EscreverStatus("Cadastro efetuado com sucesso.", false);
			}
			catch (Dominio.DominioException dominioException)
			{
				EscreverStatus(dominioException.Message, true);
			}
			catch (Exception exception)
			{
				EscreverStatus(String.Format("Erro desconhecido tente mais tarde.<br />{0}", exception.Message), true);
			}
		}

		/// <summary>
		/// Escreve o Status na Tela.
		/// </summary>
		/// <param name="mensagem"></param>
		/// <param name="erro"></param>
		private void EscreverStatus(string mensagem, Boolean erro)
		{
			LabelMensagem.InnerHtml = mensagem;

			if (erro)
				LabelMensagem.Attributes.Add("style", "color:red;");
			else
				LabelMensagem.Attributes.Remove("style");
		}

	}
}
