﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao
{
    /// <summary>
    /// Exceção que trata as regras de negocio do Domínio.
    /// </summary>
    [Serializable]
    public class AplicacaoException : Exception
    {
        /// <summary>
        /// 
        /// </summary>
        public AplicacaoException() { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        public AplicacaoException(string message)
            : base(message) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="inner"></param>
        public AplicacaoException(string message, Exception inner)
            : base(message, inner) { }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="info"></param>
        /// <param name="context"></param>
        protected AplicacaoException(SerializationInfo info, StreamingContext context)
            : base(info, context) { }
    }
}
