﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos
{
    /// <summary>
    /// Gerenciador de Campos para tela de inserção.
    /// </summary>
    public class GerenciadorCamposInserir : GerenciadorCamposBase
    {
        /// <summary>
        /// Construtor.
        /// </summary>
        /// <param name="table"></param>
        public GerenciadorCamposInserir(MetaTable table)
            : base(table)
        {
        }

        /// <summary>
        /// Popula os campos
        /// </summary>
        /// <param name="colunas"></param>
        /// <returns></returns>
        public override List<DynamicField> PopularCampos(List<MetaColumn> colunas)
        {
            var oFields = new List<DynamicField>();

            foreach (MetaColumn column in colunas)
            {
                if (!column.Scaffold)
                    continue;

                DynamicField f = new DynamicField();

                if (!column.Attributes.OfType<ReadOnlyAttribute>().
                    DefaultIfEmpty(new ReadOnlyAttribute(false)).
                    FirstOrDefault().IsReadOnly)
                {
                    f.DataField = column.Name;
                    oFields.Add(f);
                }
            }

            return oFields;
        }
    }
}
