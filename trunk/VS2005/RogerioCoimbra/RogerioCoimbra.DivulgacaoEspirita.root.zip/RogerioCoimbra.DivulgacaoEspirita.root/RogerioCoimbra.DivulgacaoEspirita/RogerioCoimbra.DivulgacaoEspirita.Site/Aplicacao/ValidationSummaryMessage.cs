﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao
{
	public class MensagemValidacao : IValidator
	{
		private string mensagem;

		/// <summary>
		/// Construtor
		/// </summary>
		private MensagemValidacao(string mensagem)
		{
			this.mensagem = mensagem;
		}

		/// <summary>
		/// Cria uma mensagem de validação.
		/// </summary>
		/// <param name="mensagem"></param>
		/// <returns></returns>
		public static MensagemValidacao Criar(string mensagem)
		{
			return new MensagemValidacao(mensagem);
		}

		#region IValidator Members

		/// <summary>
		/// ErrorMessage
		/// </summary>
		public string ErrorMessage
		{
			get
			{
				return this.mensagem;
			}
			set{}
		}

		/// <summary>
		/// IsValid
		/// </summary>
		public bool IsValid
		{
			get
			{
				return false;
			}
			set{}
		}

		/// <summary>
		/// Validate
		/// </summary>
		public void Validate()
		{}

		#endregion
	}
}
