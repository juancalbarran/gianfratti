﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao
{
    public class Autenticacao
    {
    }
}
