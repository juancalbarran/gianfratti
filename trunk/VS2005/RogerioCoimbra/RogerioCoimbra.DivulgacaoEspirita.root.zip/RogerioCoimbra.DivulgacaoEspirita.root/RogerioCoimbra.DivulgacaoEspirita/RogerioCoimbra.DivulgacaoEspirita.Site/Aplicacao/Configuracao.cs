﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao
{
	public static class Configuracao
	{
		private static string paginaInicial;

		/// <summary>
		/// Pagina inicial do Sistema.
		/// </summary>
		public static string PaginaInicial
		{
			get
			{
				if (String.IsNullOrEmpty(paginaInicial))
					paginaInicial = ConfigurationManager.AppSettings["PaginaInicial"];

				return paginaInicial;
			}
		}
	}
}
