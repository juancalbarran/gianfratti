﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos
{
    /// <summary>
    /// DynamicReadonlyField
    /// </summary>
    public class CampoDinamicoApenasLeitura : DynamicField
    {
        public override void InitializeCell(
            DataControlFieldCell cell,
            DataControlCellType cellType,
            DataControlRowState rowState,
            int rowIndex)
        {
            if (cellType == DataControlCellType.DataCell)
            {
                var control = new DynamicControl() { DataField = DataField };

                // Copy various properties into the control
                control.UIHint = UIHint;
                control.HtmlEncode = HtmlEncode;
                control.NullDisplayText = NullDisplayText;

                // this the default for DynamicControl and has to be 
                // manually changed you do not need this line of code
                // its there just to remind us what we are doing.
                control.Mode = DataBoundControlMode.ReadOnly;

                cell.Controls.Add(control);
            }
            else
            {
                base.InitializeCell(cell, cellType, rowState, rowIndex);
            }
        }
    }
}
