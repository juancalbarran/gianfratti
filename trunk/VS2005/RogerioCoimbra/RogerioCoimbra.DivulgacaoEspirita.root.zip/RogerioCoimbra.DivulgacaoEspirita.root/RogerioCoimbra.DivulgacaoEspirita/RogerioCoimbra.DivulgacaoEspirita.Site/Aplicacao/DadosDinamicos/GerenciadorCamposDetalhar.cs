﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.DynamicData;
using System.Web.UI;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos
{
    /// <summary>
    /// Gerenciador de Campos para tela de detalhamento.
    /// </summary>
    public class GerenciadorCamposDetalhar : GerenciadorCamposBase
    {
        /// <summary>
        /// Construtor.
        /// </summary>
        /// <param name="table"></param>
        public GerenciadorCamposDetalhar(MetaTable table)
            : base(table)
        {
        }

        /// <summary>
        /// Popula os campos
        /// </summary>
        /// <param name="colunas"></param>
        /// <returns></returns>
        public override List<DynamicField> PopularCampos(List<MetaColumn> colunas)
        {
            var oFields = new List<DynamicField>();

            foreach (MetaColumn column in colunas)
            {
                if (!column.Scaffold)
                    continue;

                DynamicField f = new DynamicField();

                f.DataField = column.Name;
                oFields.Add(f);
            }

            return oFields;
        }
    }
}
