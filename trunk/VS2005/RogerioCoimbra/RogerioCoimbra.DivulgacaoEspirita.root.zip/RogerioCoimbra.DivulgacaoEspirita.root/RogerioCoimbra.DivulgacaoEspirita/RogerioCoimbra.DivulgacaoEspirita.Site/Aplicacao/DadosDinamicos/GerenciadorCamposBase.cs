﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.DynamicData;
using System.Web.UI;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos
{
    /// <summary>
    /// Implementa o comportamento básico dos gerenciadores de campos.
    /// </summary>
    public abstract class GerenciadorCamposBase : IAutoFieldGenerator
    {
        protected MetaTable _table;

        public GerenciadorCamposBase(MetaTable table)
        {
            _table = table;
        }

        public ICollection GenerateFields(Control control)
        {
			List<MetaColumn> columns = _table.Columns.Where(column => !column.Attributes.Contains(new DisplayNameAttribute())).ToList();

            // Order the columns of this table .
            if (_table.Attributes.Matches(new ColunasOrdenadasAttribute()))
                try
                {
					columns = columns.OrderBy(column => ((OrdemColunaAttribute)column.Attributes[typeof(OrdemColunaAttribute)]).Order).ToList();
                }
                catch (System.NullReferenceException)
                {
					throw (new AplicacaoException("o atributo 'ColumnOrderAttribute' deve ser implementado nos campos visíveis."));
                }
            else
                columns = _table.Columns.ToList();


            return PopularCampos(columns);
        }

        /// <summary>
        /// Popula os campos
        /// </summary>
        /// <param name="colunas"></param>
        /// <returns></returns>
        public abstract List<DynamicField> PopularCampos(List<MetaColumn> colunas);
    }
}
