﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web.DynamicData;
using System.Web.UI;
using RogerioCoimbra.DivulgacaoEspirita.Dominio.Entidade.Metadata;

namespace RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos
{
    /// <summary>
    /// Gerenciador de Campos para tela de Listagem.
    /// </summary>
    public class GerenciadorCamposListar : GerenciadorCamposBase
    {
        /// <summary>
        /// Construtor.
        /// </summary>
        /// <param name="table"></param>
        public GerenciadorCamposListar(MetaTable table)
            : base(table)
        {
        }

        /// <summary>
        /// Popula os campos
        /// </summary>
        /// <param name="colunas"></param>
        /// <returns></returns>
        public override List<DynamicField> PopularCampos(List<MetaColumn> colunas)
        {
            var oFields = new List<DynamicField>();
        	bool campoTextoLongoExcecao;

            foreach (MetaColumn column in colunas)
            {
            	campoTextoLongoExcecao =
            		(column.Table.Name == "Frase" && column.Name == "Conteudo");

				if (!column.Scaffold || (column.IsLongString && !campoTextoLongoExcecao))
                    continue;

                DynamicField f = new DynamicField();

                f.DataField = column.Name;
                oFields.Add(f);
            }

            return oFields;
        }
    }
}
