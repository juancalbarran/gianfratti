﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;

namespace RogerioCoimbra.DivulgacaoEspirita.Site
{
	public partial class TextField : System.Web.DynamicData.FieldTemplateUserControl
	{
        protected override void OnDataBinding(EventArgs e)
        {
            base.OnDataBinding(e);

			DataTypeAttribute dataTypeAttribute = Column.Attributes.OfType<DataTypeAttribute>().FirstOrDefault();
			if (dataTypeAttribute != null && dataTypeAttribute.DataType == DataType.Password)
			{
				Literal1.Text = new String('*', 6);
			}
			else
			    Literal1.Text = FieldValueString;
        }

		public override Control DataControl
		{
			get
			{
				return Literal1;
			}
		}
	}
}
