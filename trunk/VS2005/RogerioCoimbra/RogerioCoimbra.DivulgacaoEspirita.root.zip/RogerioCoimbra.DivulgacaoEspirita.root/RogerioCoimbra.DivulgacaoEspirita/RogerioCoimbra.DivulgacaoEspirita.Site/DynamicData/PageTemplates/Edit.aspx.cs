﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.DynamicData;
using RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao;
using RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos;

namespace RogerioCoimbra.DivulgacaoEspirita.Site
{
	public partial class Edit : System.Web.UI.Page
	{
		protected MetaTable table;

		protected void Page_Init(object sender, EventArgs e)
		{
            DynamicDataManager1.RegisterControl(DetailsView1);
            table = DetailsDataSource.GetTable();
            DetailsView1.RowsGenerator = new GerenciadorCamposEditar(table);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			table = DetailsDataSource.GetTable();
			Title = table.DisplayName;
			DetailsDataSource.Include = table.ForeignKeyColumnsNames;
		}

		protected void DetailsView1_ItemCommand(object sender, DetailsViewCommandEventArgs e)
		{
			if (e.CommandName == DataControlCommands.CancelCommandName)
			{
				Response.Redirect(table.ListActionPath);
			}
		}

		protected void DetailsView1_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
		{
			if (e.Exception != null)
			{
				Page.Validators.Add(MensagemValidacao.Criar(String.Format("{0} {1}", "Erro desconhecido: ", e.Exception.GetBaseException().Message)));
			}
			else
			{
				Response.Redirect(table.ListActionPath);
			}
		}
	}
}
