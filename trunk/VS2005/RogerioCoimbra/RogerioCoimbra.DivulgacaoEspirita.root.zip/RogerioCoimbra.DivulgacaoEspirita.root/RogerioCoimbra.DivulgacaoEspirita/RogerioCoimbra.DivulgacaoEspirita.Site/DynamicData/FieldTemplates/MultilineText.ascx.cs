﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.DynamicData;

namespace RogerioCoimbra.DivulgacaoEspirita.Site
{
	public partial class MultilineText_Field : System.Web.DynamicData.FieldTemplateUserControl
	{
		protected override void OnDataBinding(EventArgs e)
		{
			base.OnDataBinding(e);

			string campoString = InserirParagrafos(FieldValueString);

			if (Request.Url.Segments.Contains("Listar.aspx") && !string.IsNullOrEmpty(FieldValueString) && Table.Name == "Frase" && Column.Name == "Conteudo")
			{
				const int comprimentoMaximo = 50;
				if (FieldValueString.Length>comprimentoMaximo)
					campoString = String.Format("{0}...", FieldValueString.Substring(0, comprimentoMaximo));
			}

			Literal1.Text = campoString;
		}

		public override Control DataControl
		{
			get
			{
                return Literal1;
			}
		}

        /// <summary>
        /// Insere paragrafos no texto.
        /// </summary>
        /// <param name="texto"></param>
        /// <returns></returns>
        protected string InserirParagrafos(string texto)
        {
            return texto.Replace("\n", "<br />");
        }
	}
}
