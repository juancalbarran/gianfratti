﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using System.Web.DynamicData;
using System.ComponentModel.DataAnnotations;
using RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao;
using RogerioCoimbra.DivulgacaoEspirita.Site.Aplicacao.DadosDinamicos;
using RogerioCoimbra.DivulgacaoEspirita.InfraEstrutura.MetodosEstendidos;

namespace RogerioCoimbra.DivulgacaoEspirita.Site
{
	public partial class List : System.Web.UI.Page
	{
		protected MetaTable table;

		protected void Page_Init(object sender, EventArgs e)
		{
			DynamicDataManager1.RegisterControl(GridView1, true /*setSelectionFromUrl*/);
            table = GridDataSource.GetTable();
            GridView1.ColumnsGenerator = new GerenciadorCamposListar(table);
		}

		protected void Page_Load(object sender, EventArgs e)
		{
			table = GridDataSource.GetTable();
			Title = table.DisplayName;
			GridDataSource.Include = table.ForeignKeyColumnsNames;
			InsertHyperLink.NavigateUrl = table.GetActionPath(PageAction.Insert);

			// Disable various options if the table is readonly
			if (table.IsReadOnly)
			{
				GridView1.Columns[0].Visible = false;
				InsertHyperLink.Visible = false;
			}

			var displayColumn = table.GetAttribute<DisplayColumnAttribute>();
			if (displayColumn != null && displayColumn.SortColumn != null)
			{
				GridDataSource.OrderBy =
					string.Format("it.[{0}] {1}", displayColumn.SortColumn, displayColumn.SortDescending ? "DESC" : "ASC");
			}
		}

		protected void OnFilterSelectedIndexChanged(object sender, EventArgs e)
		{
			GridView1.PageIndex = 0;
		}

		protected void GridDataSource_Deleted(object sender, EntityDataSourceChangedEventArgs e)
		{
			if (e.Exception != null)
			{
				string mensagemErro = null;

				if(e.Exception.InnerException is System.Data.SqlClient.SqlException)
				{
					switch (table.Name)
					{
						case "PalestraSemanal":
							mensagemErro = "A Palestra Semanal selecionada não pode ser excluida, pois esta associada a um usuário.";
							break;
						case "Usuario":
							mensagemErro = "O Usuário selecionado não pode ser excluido, pois esta associado a outros registros.";
							break;
						case "Autor":
							mensagemErro = "O Autor selecionado não pode ser excluido, pois esta associado a uma frase.";
							break;
					}
				}
				else
				{
					mensagemErro = String.Format("{0} {1}", "Erro desconhecido: ", e.Exception.GetBaseException().Message);
				}

				Page.Validators.Add(MensagemValidacao.Criar(mensagemErro));
			}
		}
	}
}
