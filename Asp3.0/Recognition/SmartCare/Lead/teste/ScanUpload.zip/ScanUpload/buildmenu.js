
 
  mnuLinks = new popupMenu('mnuLinks', 20, 140, 70, 20, 110); 
  mnuLinks.createMainMenu('Links', '#E4E6FF', 'black', 'black');
  mnuLinks.createMenuItem('#E4E6FF', 'black', 
    '<A HREF="http://www.LEADTOOLS.com">Home</A><br>'+
    '<A HREF="http://support.LEADTOOLS.com">Customers Only</A>'
    );