--------------------------------------------------------------------
  LeechFTP 1.3 (Build 207) released 16.04.99
--------------------------------------------------------------------

 - Fixed common control version problem with IE5/Win2000 (comctl32.dll v5.x)
 - Recursive Transfers now respect the ASCII files extension setting
 - Protection Faults on program shutdown hopefully fixed

--------------------------------------------------------------------
 Feedback
--------------------------------------------------------------------
 If you have serious problems concerning running this software or if
 you discover any bugs, feel free to contact me. Due to the 
 overwhelming number of mails I receive daily, I cannot guarantee to
 reply to every mail.

 My mail address: Jan Debis <debis@rz.fh-heilbronn.de>

 Checkout my home page for any news regarding LeechFTP
   http://linux.fh-heilbronn.de/~debis/leechftp/

--------------------------------------------------------------------
 $$$
-------------------------------------------------------------------- 
 Also, if you like this software and want to express your gratitude
 or to encourage further development, feel free to donate some money,
 or even hardware. I'm a student and would happily accept any
 donations. Please do not send cheques, as cashing them in is 
 very  expensive in Germany. US cash would be ok.

 Any donations are welcome, send them to

             Jan Debis 
             Humboldtstrasse 12
             74076 Heilbronn
             GERMANY

--------------------------------------------------------------------
 Known Limitations:
--------------------------------------------------------------------
 Bookmarks are loaded on program startup and saved when leaving
 the program. So if you load several instances of the program,
 you might loose any changes to your bookmarks, depending on which
 instance quits first.  

--------------------------------------------------------------------
 License
--------------------------------------------------------------------
 This software is released as FREEWARE, but it may not be sold or be
 included in a product or package which intends to receive benefits 
 through the inclusion of this software. This software may be be 
 distributed freely over the internet as long as the files remain 
 unmodified. This software may not be included on CD-ROMs without 
 prior permission from the author.

--------------------------------------------------------------------
 DISCLAIMER
--------------------------------------------------------------------
THIS SOFTWARE AND THE ACCOMPANYING FILES ARE DISTRIBUTED "AS IS" AND
WITHOUT ANY WARRANTIES WHETHER EXPRESSED OR IMPLIED. NO REPONSIBILITIES
FOR POSSIBLE DAMAGES OR EVEN FUNCTIONALITY CAN BE TAKEN. THE USER MUST 
ASSUME THE ENTIRE RISK OF USING THIS PROGRAM. 
--------------------------------------------------------------------

--------------------------------------------------------------------
Developed by
Jan Debis <debis@rz.fh-heilbronn.de>
74076 Heilbronn / Germany
--------------------------------------------------------------------
