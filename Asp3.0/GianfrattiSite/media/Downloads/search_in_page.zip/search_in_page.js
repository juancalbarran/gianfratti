/******************************************
* Find In Page Script -- Submitted/revised by Alan Koontz (alankoontz@REMOVETHISyahoo.com)
* Visit Dynamic Drive (http://www.dynamicdrive.com/) for full source code
* Modified Jan 4th, 03'. This notice must stay intact for use
******************************************/

//  revised by Alan Koontz -- 9/18/02
//  further revised by Kevin Roth on 4/8/03

var TRange = null;
var win = null;
var frameval = false;

function search(whichform, whichframe) {
	//  TEST FOR IE5 FOR MAC (NO DOCUMENTATION)
	if (browser.isIE4up && browser.isMac) return;
	
	//  TEST FOR NAV 6 (NO DOCUMENTATION)
	if (browser.isGecko && (browser.geckoRevision < 1)) return;
	
	//  INITIALIZATIONS FOR FIND-IN-PAGE SEARCHES
	if(whichform.findthis.value != null && whichform.findthis.value != '') {
		str = whichform.findthis.value;
		if(whichframe != self)
		frameval = true;  // this will enable Nav7 to search child frame
		win = whichframe;
	}
	else return;  //  i.e., no search string was entered
	
	var strFound;
	
	//  NAVIGATOR 4 SPECIFIC CODE
	if(browser.isNS4x && (browser.versionMinor < 5)) {
		strFound = win.find(str); // case insensitive, forward search by default
		
		//  There are 3 arguments available:
		//  searchString: type string and it's the item to be searched
		//  caseSensitive: boolean -- is search case sensitive?
		//  backwards: boolean --should we also search backwards?
		//  strFound=win.find(str, false, false) is the explicit
		//  version of the above
		//  The Mac version of Nav4 has wrapAround, but
		//  cannot be specified in JS
	}
	
	//  NAVIGATOR 7 SPECIFIC CODE (WILL NOT WORK WITH NAVIGATOR 6)
	if (browser.isGecko && (browser.geckoRevision >= 1)) {
		if(frameval != false) win.focus(); // force search in specified child frame
		strFound = win.find(str, false, false, true, false, frameval, false);
		
		//  There are 7 arguments available:
		//  searchString: type string and it's the item to be searched
		//  caseSensitive: boolean -- is search case sensitive?
		//  backwards: boolean --should we also search backwards?
		//  wrapAround: boolean -- should we wrap the search?
		//  wholeWord: boolean: should we search only for whole words
		//  searchInFrames: boolean -- should we search in frames?
		//  showDialog: boolean -- should we show the Find Dialog?
	}
	
	//IE4+ SPECIFIC CODE
	if (browser.isIE4up) {
		if (TRange != null) {
			TRange.collapse(false)
			strFound = TRange.findText(str)
			if (strFound) TRange.select();
		}
		if (TRange == null || strFound == 0) {
			TRange = win.document.body.createTextRange()
			strFound = TRange.findText(str)
			if (strFound) TRange.select();
		}
	}
	
	if (!strFound) alert ("String '"+str+"' not found!") // string not found
}
