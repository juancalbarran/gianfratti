


ProduKey v1.06
Copyright (c) 2005 - 2006 Nir Sofer
Web Site: http://www.nirsoft.net



Description
===========

ProduKey is a small utility that displays the ProductID and the CD-Key of
MS-Office, Windows, Exchange Server, and SQL Server installed on your
computer. You can view this information for your current running
operating system, or for another operating system/computer - by using
command-line options. This utility can be useful if you lost the product
key of your Windows/Office, and you want to reinstall it on your computer.



Versions History
================


* Version 1.06 - Added support for SQL Server 2005.
* Version 1.05
  o Display information in the status bar while scanning computers
    with /remoteall and /remotefile options
  o New option /remotealldomain - scan all computers in the specified
    domain.
  o Changes in the way that /remoteall scan all computers.

* Version 1.04 - Added product key of Exchange Server.
* Version 1.03 - new command-line option: /remoteall
* Version 1.02 - On newer versions of Office (XP/2003) - display the
  real product name, if it's written in the Registry.
* Version 1.01 - Added support for XP visual style.
* Version 1.00 - First release.



Known Problems
==============


* If you bought your computer with installed operating system, you may
  find the product key appeared in ProduKey utility is different from the
  product key on your Windows CD. This problem is mostly reported with
  Dell computers.
* From unknown reason, the product key of Visual Stuido .NET is written
  in the Registry as Office XP product...
* In old versions of Office (Office 2000 and below), the 'Product Key'
  value is not available.



Using ProduKey
==============

ProduKey doesn't requite any installation process or additional DLLs. In
order to start using it, just run the executable file - produkey.exe
The main window of ProduKey displays the list of Windows, Office, and SQL
Server products installed on your system. For each product, the "Product
ID" and "Product Key" are displayed. If you want the view the product key
information in another computer, or in another operating system within
the same computer, use the command-line options below.



Command-Line Options
====================



/remoteall
Enumerate all computers on your local network, and load the product key
information from them. Be aware that this option is quite slow, and you
may need to wait a few minutes until the product key information is
displayed. In order to use this option, you must have Administrator
privileges in all computers on your local network.

/remotealldomain [Domain Name]
Enumerate all computers in the specified domain, and load the product key
information from them.

/remote [Computer Name]
Load product key information from the specified computer name. In order
to use this option, you must log in to the remote computer with
Administrator privileges.

/remotefile [Computer Names Filename]
Load product key information from all computer names specified in the
file. The file can be tab-delimited, comma-delimited, or CRLF-delimited.
In order to use this option, you must have Administrator privileges in
all computers specified in the computer names file.

/windir [Windows Directory]
Load product key information from another operating system on the same
computer. The [Windows Directory] specifies the base folder of Windows
installation, for example: c:\windows, c:\winnt

This feature is only supported on Windows 2000/XP.

/regfile [Software Registry File]
Load product key information from another operating system on the same
computer. The [Software Registry File] specifies the software registry
file usually located under c:\windows\system32\config

This feature is only supported on Windows 2000/XP.

/nosavereg
Load ProduKey without saving your last settings (window location, columns
size, and so on) to the Registry.

You can also combine the above command-line options with the following
save options in order to save product key information to file:

/stext <Filename>
Save the list of product keys into a regular text file.

/stab <Filename>
Save the list of product keys into a tab-delimited text file.

/stabular <Filename>
Save the list of product keys into a tabular text file.

/shtml <Filename>
Save the list of product keys into HTML file.

/sverhtml <Filename>
Save the list of product keys into vertical HTML file.

/sxml <Filename>
Save the list of product keys into XML file.

Examples:
produkey.exe /remote \\Server01
produkey.exe /remotefile "c:\temp\computers.txt"
produkey.exe /regfile "F:\WINNT\system32\config\software"
produkey.exe /windir "c:\winnt" /shtml "c:\temp\pk.html"
produkey.exe /remoteall
produkey.exe /remotealldomain MyDomain



System Requirements
===================

ProduKey works on all 32-bit versions of Windows. However, some features,
like viewing the product keys of another operating system instance, are
only supported on Windows 2000/XP

License
=======

This utility is released as freeware. You are allowed to freely
distribute this utility via floppy disk, CD-ROM, Internet, or in any
other way, as long as you don't charge anything for this. If you
distribute this utility, you must include all files in the distribution
package, without any modification !



Disclaimer
==========

The software is provided "AS IS" without any warranty, either expressed
or implied, including, but not limited to, the implied warranties of
merchantability and fitness for a particular purpose. The author will not
be liable for any special, incidental, consequential or indirect damages
due to loss of data or any other reason.



Translating ProduKey to the languages
=====================================

In order to translate ProduKey to other language, follow the instructions
below:
1. Run ProduKey with /savelangfile parameter:
   ProduKey.exe /savelangfile
   A file named ProduKey_lng.ini will be created in the folder of
   ProduKey utility.
2. Open the created language file in Notepad or in any other text
   editor.
3. Translate all string entries to the desired language. Optionally,
   you can also add your name and/or a link to your Web site.
   (TranslatorName and TranslatorURL values) If you add this information,
   it'll be used in the 'About' window.
4. After you finish the translation, Run ProduKey, and all translated
   strings will be loaded from the language file.
   If you want to run ProduKey without the translation, simply rename the
   language file, or move it to another folder.



Feedback
========

If you have any problem, suggestion, comment, or you found a bug in my
utility, you can send a message to nirsofer@yahoo.com
