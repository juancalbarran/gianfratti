> The full schema for them all to work is;
>
> CREATE TABLE Parents (
> ID int IDENTITY (1, 1) NOT NULL ,
> strParent varchar (50) NOT NULL ,
> bitEnabled bit NOT NULL ,
> intValue int NULL
> )
>
> CREATE TABLE Children (
> ID int IDENTITY (1, 1) NOT NULL ,
> intParent int NOT NULL ,
> strChild varchar (50) NOT NULL ,
> intValue int NULL
> )
>