Licensed Fileman activeX controls
www.iisworks.com

1) Copy the files to a place where all users have permissions (for example c:\winnt\system32)

2) Run for each component: Regsvr32 <FullDLLPath>

For example: 
regsvr32 c:\winnt\system32\fathzip.dll