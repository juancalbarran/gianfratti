function loadTxt()
    {
    document.getElementById("btnClose").value = "sluiten";
    }
function writeTitle()
    {
    document.write("<title>Voorbeeld</title>")
    }