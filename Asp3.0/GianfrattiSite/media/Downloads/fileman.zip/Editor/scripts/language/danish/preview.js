function loadTxt()
    {
    document.getElementById("btnClose").value = "Luk";
    }
function writeTitle()
    {
    document.write("<title>Eksempel</title>")
    }