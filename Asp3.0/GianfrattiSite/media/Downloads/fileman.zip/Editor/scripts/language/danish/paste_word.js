function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "Inds\u00E6t Word indhold her";
    document.getElementById("btnCancel").value = "Annuller";
    document.getElementById("btnOk").value = " ok ";   
	}
function writeTitle()
	{
	document.write("<title>Inds\u00E6t Fra Word</title>")
	}