function loadTxt()
	{
    document.getElementById("txtLang").innerHTML = "\u5f9e MS Word\u8cbc\u4e0a\u5167\u5bb9  (CTRL-V) ";
    document.getElementById("btnCancel").value = "\u53d6\u6d88 ";
    document.getElementById("btnOk").value = " \u78ba\u8a8d  ";   
	}
function writeTitle()
	{
	document.write("<title>\u5f9e MS Word\u8cbc\u4e0a\u5167\u5bb9 </title>")
	}
