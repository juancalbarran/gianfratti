function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML Kode";
    document.getElementById("btnClose").value = "Lukk";
    }
function writeTitle()
    {
    document.write("<title>Symboler</title>")
    }