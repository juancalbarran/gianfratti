function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Code HTML";
    document.getElementById("btnClose").value = "Fermer";
    }
function writeTitle()
    {
    document.write("<title>Caract&egrave;res Sp\u00E9ciaux</title>")
    }