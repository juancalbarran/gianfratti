
RegSeeker Copyright 2002-2007 Hover Inc.
Thibaud DJIAN


RegSeeker website   : http://www.hoverdesk.net/freeware.htm
Hover Inc. website  : http://www.hoverdesk.net
Contact information : contact@hoverdesk.net

---------------------------------------------------------------------------------------------------

RegSeeker is the perfect companion for your Windows registry ! 
RegSeeker includes a powerful registry cleaner and can display various informations like your startup entries, several histories (even index.dat files), installed applications and much more ! With RegSeeker you can search for any item inside your registry, export/delete the results, open them in the registry. RegSeeker also includes a tweaks panel to optimize your OS !

WARNING !
Incorrectly editing the registry may severely damage your system. At the very least, you should back up any valued data on the computer before making changes to the registry. RegSeeker is provided 'as is'. Use at your own risk.

RegSeeker is FREE for PERSONAL USE ONLY !
For any usage in any Company or Organization, please contact us (contact@hoverdesk.net) for licensing informations.
You can not redistribute nor sell RegSeeker without author's agreement.

CLEANER USAGE NOTE : When using the Registry Cleaner, once your entries are listed, select the ones you want to remove and hit the "DEL" key or right-click in the listbox to display the popup menu.


