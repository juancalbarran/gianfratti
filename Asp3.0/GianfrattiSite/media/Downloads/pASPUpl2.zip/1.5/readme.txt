  PSTRUH PureASP file upload v1.5
c 1998-2001 Antonin Foller, PSTRUH Software
http://www.pstruh.cz

  PureASP upload LICENSE

  PureASP upload (upload.inc script) is a freeware with a limitted use. 
It was created as a free promo code for ScriptUtilities library - and its
upload solution for ASP/IIS.

  You can use Pure-ASP upload without additional licenses
to upload files with size up to 10MB for free. Please include 
<A Href="http://www.pstruh.cz/help/scptutl/upload.asp">Pure-ASP file upload</A>
or similar text link to http://www.pstruh.cz on the web site using 
Pure-ASP upload.

	Remember that latest version of PureASP upload is 2.0. You can see 
latest version and notes at http://www.pstruh.cz/help/scptutl/upload.asp.

  Huge-ASP upload and ScriptUtilities registration

  What do you will get if you register?
1. Enhanced Pure-ASP upload code, which lets your clients upload files
   with size up to 100MB and progress bar

2. Full version of HugeASP upload with
 - upload files from bytes to gigabytes with exciting performance
 - low memory consumption (10kBs/upload)
 - work with any code page (including utf-8, MAC, ANSI, OEM, etc.)
   see http://pstruh.cz/help/scptutl/cl68.htm
 - application/x-www-form-urlencoded handling with same performance
 - Header handling with several code pages
 - File state in progress bar (you will see uploading file names)
 - Enhanced SQL upload - up to 2GB to SQL binary data field

3. Other ScriptUtilities functionality
 - Huge-file download - unlimitted size (2GB, also >2GB) with minimum
   server resources (memory, processor)
 - ByteArray class to hi-speed work with binary and conversions (HexString)
 - INI file work kernel and user library calls
 - Enhanced timing and script performance monitoring (up to 1ns)

  DISCLAIMER OF WARRANTY

  I worked a lot of time on PureASP upload code, but 
  THIS SOFTWARE AND THE ACCOMPANYING FILES ARE DELIVERED 
"AS IS" AND WITHOUT WARRANTIES AS TO PERFORMANCE 
OR MERCHANTABILITY OR ANY OTHER WARRANTIES 
WHETHER EXPRESSED OR IMPLIED. 
  

  DISTRIBUTION

  You can re-distribute PureASP upload as original pack 
(http://www.pstruh.cz/dlldownload/pASPUpl2.zip). You can also
re-distribute parts of this software, but every time with
this readme file and with notice about original location
(http://www.pstruh.cz)